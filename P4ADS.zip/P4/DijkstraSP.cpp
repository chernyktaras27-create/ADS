#include <assert.h>
#include "DijkstraSP.h"

/**
 * F�ge eine Kante mit minimalen Kosten hinzu, die von einem
 * Baumknoten zu einem Nicht-Baumknoten verl�uft und deren
 * Ziel w dem Startknoten s am n�chsten ist.
 *
 * \param[in]  G		Kantengewichteter-Digraph
 * \param[in]  v		Zielknoten
 */
void DijkstraSP::relax(EdgeWeightedDigraph G, int v)
{
	// Wir betrachten alle ausgehenden Pfade vom Knoten v als vektor.
    std::vector<DirectedEdge> edges = G.getAdj(v);
    
    for (size_t i = 0; i < edges.size(); i++) {
        DirectedEdge e = edges[i];
        int w = e.to(); // Wohin führt die Straße?
        
        // Wenn der neue Weg günstiger ist als der, den wir kannten
        if (mDistToVect[w] > mDistToVect[v] + e.weight()) {
            mDistToVect[w] = mDistToVect[v] + e.weight(); // Preisaktualisierung
            mEdgeTo[w] = e; // Wir erinnern uns, woher wir kommen
            
            if (mPQ.contains(w)) {
                mPQ.change(w, mDistToVect[w]);
            } else {
                mPQ.push(w, mDistToVect[w]);
            }
        }
    }
}


/**
 * Fuert den Dijkstra Algorithmus von s, im Graph G aus.
 *
 * \param[in]  G		Kantengewichteter-Digraph
 * \param[in]  s		Startknoten
 */
DijkstraSP::DijkstraSP(EdgeWeightedDigraph G, int s)
{
	// Fülle das Distanz-Array mit einer großen Zahl
    for (int i = 0; i < G.getV(); i++) {
        mDistToVect.push_back(1000000.0); 
    }
    mDistToVect[s] = 0.0; // Entfernung zum Start - Null
    mPQ.push(s, 0.0);

    // Solange die Warteschlange nicht leer ist, wählen wir den günstigsten Knoten.
    while (!mPQ.empty()) {
        int v = mPQ.pop_top();
        relax(G, v);
    }
}

/**
 * Gibt die Distanz von s zum Knoten v zurueck
 *
 * \param[in]  v		Zielknoten
 * \return Summe der Gewichte auf dem Pfad zu v
 */
double DijkstraSP::distTo(int v) const
{
	return mDistToVect[v];
}

/**
 * Gibt zurueck ob es einen Pfad zu v von s aus gibt
 *
 * \param[in]  v		Zielknoten
 * \return true, wenn es einen Pfad von s nach v gibt, sonst false
 */
bool DijkstraSP::hasPathTo(int v) const
{
	return mDistToVect[v] < 1000000.0;
}

/**
 * Gibt den Pfad von s nach v als Vektor zurueck
 *
 * \param[in]  v		Zielknoten
 * \return Vektor mit allen Kanten des Pfades von s nach v
 */
std::vector<DirectedEdge> DijkstraSP::pathTo(int v) 
{
	std::vector<DirectedEdge> path;
    if (!hasPathTo(v)) {
        return path; // Gibt ein leeres Array zurück, wenn kein Pfad existiert.
    }

    std::vector<DirectedEdge> temp;
    int curr = v;
    
    while (mEdgeTo.find(curr) != mEdgeTo.end()) {
        DirectedEdge e = mEdgeTo[curr];
        temp.push_back(e);
        curr = e.from();
    }

    // Wir drehen das Array manuell um, sodass der Pfad vom Start zum Ziel verläuft.
    for (int i = temp.size() - 1; i >= 0; i--) {
        path.push_back(temp[i]);
    }
    
    return path;
}