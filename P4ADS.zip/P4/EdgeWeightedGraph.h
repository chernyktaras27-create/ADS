#pragma once
#include <string>
#include <algorithm>
#include <vector>
#include <iomanip>

class Edge
{
private:
	int		mEither;  // ein Knoten der Kante
	int		mOther;   // der andere Knoten der Kante
	double	mWeight;  // Kantengewicht
public:
	Edge(int either, int other, double weight) 
		: mEither{ either }
		, mOther{ other }
		, mWeight{ weight }
	{}

	double weight() const { return mWeight; } // Gewicht dieser Kante
	int either() const { return mEither; }    // einer der beiden Knoten
	int other(int vertex) const {			  // der von "vertex" verschiedene Knoten
		if (vertex == mEither) return mOther;
		else if (vertex == mOther) return mEither;
		else throw new std::invalid_argument("Illegal endpoint");
	}	  
};

inline bool operator==(const Edge& lhs, const Edge& rhs) { return lhs.weight() == rhs.weight(); }
inline bool operator!=(const Edge& lhs, const Edge& rhs) { return !operator==(lhs, rhs); }
inline bool operator< (const Edge& lhs, const Edge& rhs) { return lhs.weight() < rhs.weight(); }
inline bool operator> (const Edge& lhs, const Edge& rhs) { return  operator< (rhs, lhs); }
inline bool operator<=(const Edge& lhs, const Edge& rhs) { return !operator> (lhs, rhs); }
inline bool operator>=(const Edge& lhs, const Edge& rhs) { return !operator< (lhs, rhs); }


class EdgeWeightedGraph
{
private:
	int mV;  // Anzahl Knoten von G
	int mE;  // Anzahl Kanten von G
	std::vector<std::vector<Edge>> mAdj; // Adjazenzliste
	bool validateVertex(int v) const;
	void validateVertexWithError(int v) const;
public:
	EdgeWeightedGraph(int V);			     // Leeren Graph mit v Knoten erstellen
	EdgeWeightedGraph(std::string filename); // Graph einlesen aus Textdatei
	EdgeWeightedGraph(int V, std::vector<Edge> E);
	void add(Edge e);  						 // f�gt Kante e dem Graphen hinzu
	int getV() const;            			 // liefert Anzahl Knoten
	int getE() const;            			 // liefert Anzahl der Kanten
	std::vector<Edge> getAdj(int v) const;	 // liefert Array der adjazenten Kanten zu v
	std::vector<std::vector<Edge>> getAdj() const;
	std::vector<Edge> edges() const;	 	 // alle Kanten dieses Graphen
	const std::vector<Edge> operator[](int v) const;
	bool delEdge(Edge e);					
};

