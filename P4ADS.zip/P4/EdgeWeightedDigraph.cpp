#include <assert.h>
#include <iomanip>
#include <vector>
#include <fstream>
#include <string>
#include "EdgeWeightedDigraph.h"

/**
 * Gibt zurueck ob der Knoten v ein gueltiger Knoten im Graph ist
 *
 * \param[in]  v		Knoten
 * \return Gueltigkeit des Knoten
 */
bool EdgeWeightedDigraph::validateVertex(int v) const
{
	return v >= 0 && v < this->mV;
}

/**
 * Gibt eine Fehlermeldung aus, wenn der Knoten v im Graph nicht gueltig ist
 *
 * \param[in]  v		Knoten
 */
void EdgeWeightedDigraph::validateVertexWithError(int v) const
{
	assert(("Vertex is out of bounds!", this->validateVertex(v)));
}

/**
 * Erstellt einen Kantengewichteten-Gaph mit mV Knoten
 *
 * \param[in]  mV		Anzahl der Knoten
 */
EdgeWeightedDigraph::EdgeWeightedDigraph(int V)
	: mV{V}
	, mE{0}
{
	mAdj.resize(V);
}

/**
* Erstellt einen Kantengewichteten-Gaph anhand der Kantenliste in fname
*
* \param[in]  fname		Dateiname der Kantenliste
*/
EdgeWeightedDigraph::EdgeWeightedDigraph(std::string filename)
{
	std::ifstream infile(filename);
	int tmp_e = 0;
	infile >> this->mV >> tmp_e;

	this->mE = 0;

	this->mAdj.resize(this->mV, std::vector<DirectedEdge>());

	int v, w;
	double weight;
	while (infile >> v >> w >> weight)
	{
		this->add(DirectedEdge(v, w, weight));
	}

	assert(("Missing edges!", tmp_e == this->mE));
}

/**
 * Fuegt die Kante e zum Graphen hinzu
 *
 * \param[in]  e		Kante
 */
void EdgeWeightedDigraph::add(DirectedEdge e)
{
	this->validateVertexWithError(e.from());
	this->validateVertexWithError(e.to());

	this->mAdj[e.from()].push_back(e);

	this->mE++;
}

/**
 * Gibt die Anzahl der Knoten zurueck
 *
 * \return Anzahl der Knoten
 */
int EdgeWeightedDigraph::getV() const
{
	return this->mV;
}

/**
 * Gibt die Anzahl der Kanten zurueck
 *
 * \return Anzahl der Kanten
 */
int EdgeWeightedDigraph::getE() const
{
	return this->mE;
}

/**
 * Liefert alle benachbarten Kanten zu v
 *
 * \param[in] v Knoten von dem aus gesucht wird
 * \return Vektor mit allen benachbarten Kanten
 */
std::vector<std::vector<DirectedEdge>> EdgeWeightedDigraph::getAdj() const
{
	return this->mAdj;
}

/**
 * Liefert alle benachbarten Kanten zu v
 *
 * \param[in] v Knoten von dem aus gesucht wird
 * \return Vektor mit allen benachbarten Kanten
 */
std::vector<DirectedEdge> EdgeWeightedDigraph::getAdj(int v) const
{
	std::vector<DirectedEdge> neighbors;
	for (auto const& n : mAdj[v]) {
		neighbors.push_back(n);
	}
	return neighbors;
}

/**
 * Gibt alle Kanten im Graph zurueck
 *
 * \return Vektor mit allen Kanten im Graph
 */
std::vector<DirectedEdge> EdgeWeightedDigraph::edges() const
{
	std::vector<DirectedEdge> list;
	for (int v = 0; v < this->mV; v++)
	{
		for (DirectedEdge e : this->mAdj[v])
		{
			list.push_back(e);
		}
	}
	return list;
}

/**
 * Gibt die Kantenliste eines Knoten v zurueck
 *
 * \param[in]  v		Knoten
 * \return Vektor mit den Kanten vom Knoten v
 */
const std::vector<DirectedEdge> EdgeWeightedDigraph::operator[](int from) const
{
	return this->mAdj[from];
}

bool EdgeWeightedDigraph::delEdge(DirectedEdge e)
{
	int v = e.from(); // Wir erhalten den Startknoten

    // Wir durchlaufen die Liste der Startknoten, um diese Kante zu finden.
    for (int i = 0; i < mAdj[v].size(); i++) {
        // Wenn wir eine Kante finden, die mit unserer übereinstimmt
        if (mAdj[v][i] == e) {
            mAdj[v].erase(mAdj[v].begin() + i); // löschen es
            mE--; 
            return true; 
        }
    }
    
    // Wenn der Zyklus endet und die Kante nicht gefunden wird
    return false;

}

