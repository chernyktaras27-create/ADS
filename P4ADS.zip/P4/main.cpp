#include <iostream>
#include <string>
#include <vector>

// Підключаємо всі ваші заголовкові файли
#include "EdgeWeightedGraph.h"
#include "EdgeWeightedDigraph.h"
#include "PrimMST.h"
#include "KruskalMST.h"
#include "DijkstraSP.h"
#include "Graphsearch.h" 

void runTests();
int main() {
    runTests(); 

    int choice = 0;
    std::string filename;
    
    // Вказівники на наші графи (поки порожні)
    EdgeWeightedGraph* G = nullptr;
    EdgeWeightedDigraph* DG = nullptr;

    do {
        std::cout << "\nPraktikum 4: Graphenalgorithmen:\n";
        std::cout << "1) Graph einlesen\n";
        std::cout << "2) Tiefensuche\n";
        std::cout << "3) Breitensuche\n";
        std::cout << "4) MST nach Prim (Eingabe: Startknoten)\n";
        std::cout << "5) MST nach Kruskal\n";
        std::cout << "6) Kuerzeste Wege nach Dijkstra (Eingabe: Startknoten)\n";
        std::cout << "7) Ausgabe der Adjazenzliste\n";
        std::cout << "8) Kante loeschen\n";
        std::cout << "9) Kante hinzufuegen\n";
        std::cout << "10) Programm beenden\n";
        std::cout << "?> ";
        std::cin >> choice;

        switch (choice) {
            case 1: {
                std::cout << "Bitte Dateinamen eingeben (z.B. graph1.txt): ";
                std::cin >> filename;
                
                // Очищаємо стару пам'ять, якщо граф вже був завантажений
                if (G != nullptr) delete G;
                if (DG != nullptr) delete DG;
                
                // Створюємо обидва графи з одного файлу
                G = new EdgeWeightedGraph(filename);
                DG = new EdgeWeightedDigraph(filename);
                std::cout << "Graph erfolgreich eingelesen!\n";
                break;
            }

            case 2: {
                if (G == nullptr) { std::cout << "Graph ist leer! Bitte Punkt 1 ausfuehren.\n"; break; }
                std::vector<bool> marked(G->getV(), false);
                std::vector<int> edgeTo(G->getV(), -1);
                
                std::cout << "Tiefensuche (DFS) - Startknoten 0:\nBesuchsreihenfolge: ";
                bool connected = Graphsearch::DFS(*G, 0, marked, edgeTo);
                if (connected) std::cout << "Graph ist zusammenhaengend.\n";
                else std::cout << "Graph ist NICHT zusammenhaengend.\n";
                break;
            }
                
            case 3: {
                if (G == nullptr) { std::cout << "Graph ist leer! Bitte Punkt 1 ausfuehren.\n"; break; }
                std::vector<bool> marked(G->getV(), false);
                std::vector<int> edgeTo(G->getV(), -1);
                
                std::cout << "Breitensuche (BFS) - Startknoten 0:\nBesuchsreihenfolge: ";
                bool connected = Graphsearch::BFS(*G, 0, marked, edgeTo);
                if (connected) std::cout << "Graph ist zusammenhaengend.\n";
                else std::cout << "Graph ist NICHT zusammenhaengend.\n";
                break;
            }

            case 4: {
                if (G == nullptr) { std::cout << "Graph ist leer! Bitte Punkt 1 ausfuehren.\n"; break; }
                int start;
                std::cout << "Startknoten eingeben: ";
                std::cin >> start;
                
                PrimMST prim(*G, start);
                std::cout << "MST nach Prim - Gewicht: " << prim.weight() << "\nKanten: ";
                std::vector<Edge> edges = prim.edges();
                for (size_t i = 0; i < edges.size(); i++) {
                    std::cout << edges[i].either() << "-" << edges[i].other(edges[i].either()) << " ";
                }
                std::cout << "\n";
                break;
            }

            case 5: {
                if (G == nullptr) { std::cout << "Graph ist leer! Bitte Punkt 1 ausfuehren.\n"; break; }
                
                KruskalMST kruskal(*G);
                std::cout << "MST nach Kruskal - Gewicht: " << kruskal.weight() << "\nKanten: ";
                std::vector<Edge> edges = kruskal.edges();
                for (size_t i = 0; i < edges.size(); i++) {
                    std::cout << edges[i].either() << "-" << edges[i].other(edges[i].either()) << " ";
                }
                std::cout << "\n";
                break;
            }

            case 6: {
                if (DG == nullptr) { std::cout << "Graph ist leer! Bitte Punkt 1 ausfuehren.\n"; break; }
                int start, target;
                std::cout << "Startknoten eingeben: ";
                std::cin >> start;
                DijkstraSP dijkstra(*DG, start);
                
                std::cout << "Zielknoten eingeben: ";
                std::cin >> target;
                
                std::vector<DirectedEdge> path = dijkstra.pathTo(target);
                if (path.empty() && start != target) {
                    std::cout << "Kein Pfad von " << start << " nach " << target << " gefunden!\n";
                } else {
                    std::cout << "Pfad: " << start;
                    for (size_t i = 0; i < path.size(); i++) {
                        std::cout << " -> " << path[i].to();
                    }
                    std::cout << "\nKosten: " << dijkstra.distTo(target) << "\n";
                }
                break;
            }

            case 7: {
                if (G == nullptr) { std::cout << "Graph ist leer! Bitte Punkt 1 ausfuehren.\n"; break; }
                std::cout << "Adjazenzliste:\n";
                for (int i = 0; i < G->getV(); i++) {
                    std::cout << i << " : ";
                    std::vector<Edge> edges = G->getAdj(i);
                    for (size_t j = 0; j < edges.size(); j++) {
                        std::cout << edges[j].other(i) << " (" << edges[j].weight() << ")   ";
                    }
                    std::cout << "\n";
                }
                break;
            }

            case 8: {
                if (G == nullptr) { std::cout << "Graph ist leer! Bitte Punkt 1 ausfuehren.\n"; break; }
                int u, v;
                std::cout << "Kante loeschen - von Knoten: "; std::cin >> u;
                std::cout << "nach Knoten: "; std::cin >> v;
                
                bool deleted = false;
                std::vector<Edge> adjEdges = G->getAdj(u);
                for(size_t i = 0; i < adjEdges.size(); i++) {
                    if(adjEdges[i].other(u) == v) {
                        deleted = G->delEdge(adjEdges[i]);
                        DG->delEdge(DirectedEdge(u, v, adjEdges[i].weight())); // Синхронізуємо орієнтований граф
                        break;
                    }
                }
                
                if(deleted) std::cout << "Kante erfolgreich geloescht!\n";
                else std::cout << "Kante nicht gefunden!\n";
                break;
            }

            case 9: {
                if (G == nullptr) { std::cout << "Graph ist leer! Bitte Punkt 1 ausfuehren.\n"; break; }
                int u, v; double w;
                std::cout << "Kante hinzufuegen - von Knoten: "; std::cin >> u;
                std::cout << "nach Knoten: "; std::cin >> v;
                std::cout << "Gewicht: "; std::cin >> w;
                
                G->add(Edge(u, v, w));
                DG->add(DirectedEdge(u, v, w)); // Синхронізуємо орієнтований граф
                std::cout << "Kante erfolgreich hinzugefuegt!\n";
                break;
            }

            case 10:
                std::cout << "Programm wird beendet.\n";
                break;
                
            default:
                std::cout << "Ungueltige Eingabe!\n";
        }
    } while (choice != 10);

    // Очищення пам'яті перед виходом
    if (G != nullptr) delete G;
    if (DG != nullptr) delete DG;

    return 0;
}