#pragma once
#include <vector>
#include <queue>
#include "EdgeWeightedGraph.h"

class KruskalMST
{
private:
	std::vector<Edge> mMST;				// MST-Kanten
	std::vector<int> mTreeID;			// BaumId zu jedem Knoten
public:
	KruskalMST() {};
	KruskalMST(EdgeWeightedGraph G);
	std::vector<Edge> edges() const;	// liefert MST
	double weight() const;     			// berechnet Gesamtkosten des MST
};
