#pragma once
#include <vector>
#include <queue>
#include <map>
#include "EdgeWeightedDigraph.h"
#include "PriorityQueue.h"
#include <iostream>
#include <iomanip>

class DijkstraSP
{
private:
	std::map<int, DirectedEdge> mEdgeTo;		 
	std::vector<double> mDistToVect;			
	Utils::PriorityQueue<int> mPQ;
	void relax(EdgeWeightedDigraph G, int v);
	void printEdgeTo(EdgeWeightedDigraph G);

public:
	DijkstraSP() {};
	DijkstraSP(EdgeWeightedDigraph G, int s);
	double distTo(int v) const;					// Abst�nde vom Startvertex zu v
	bool hasPathTo(int v) const;				// �berpr�ft die existens eines Pfades
	std::vector<DirectedEdge> pathTo(int v) ;	// Kanten des k�rzsesten Weges
};

