#include "KruskalMST.h"
#include "PriorityQueue.h"
/**
 * Erstellt einen MST zum Graph G mit dem Kruskal Algorithmus
 *
 * \param[in]  G		Kantengewichteter-Graph
 */
KruskalMST::KruskalMST(EdgeWeightedGraph G)
{
	// Initialisieren die Klassenvariable mTreeID.
    mTreeID.resize(G.getV());
    for (int i = 0; i < G.getV(); i++) {
        mTreeID[i] = i;
    }

    // Erstellen  Warteschlange und fügen Kanten hinzu
    Utils::PriorityQueue<Edge> pq;
    for (Edge e : G.edges()) {
        pq.push(e, e.weight());
    }

    while (!pq.empty() && mMST.size() < G.getV() - 1) {
        Edge e = pq.pop_top();
        int v = e.either();
        int w = e.other(v);

        if (mTreeID[v] != mTreeID[w]) {
            mMST.push_back(e); // Hinzufügen zu mMST-Vektor

            int oldID = mTreeID[w];
            int newID = mTreeID[v];
            for (int i = 0; i < G.getV(); i++) {
                if (mTreeID[i] == oldID) {
                    mTreeID[i] = newID;
                }
            }
        }
    }
}

/**
 * Gibt alle Kanten vom MST zurueck
 *
 * \return Vektor mit Kanten des MST
 */
std::vector<Edge> KruskalMST::edges() const
{
	return mMST;
}

/**
 * Gibt die Summe aller Gewichte im MST zurueck
 *
 * \return Summe der Gewichte im MST
 */
double KruskalMST::weight() const
{
	double sum = 0.0;
    for (Edge e : mMST) { // Рахуємо суму з вашого вектора
        sum += e.weight();
    }
    return sum;
}
