#pragma once
#include <vector>
#include <queue>

#include "EdgeWeightedGraph.h"

class PrimMST
{
private:
	std::vector<bool> mMarked;	// MST-Knoten
	std::vector<Edge> mMST;		// MST-Kanten
	/*
	 * PriorityQueue die alle Kanten speichert und mit mPQ.top()
	 * die Kante mit dem kleinsten Gewicht zurueck gibt.
	 */
	std::priority_queue<Edge, std::vector<Edge>, std::greater<Edge>> mPQ;	
public:
	PrimMST() {}
	PrimMST(EdgeWeightedGraph G, int s);
	void visit(EdgeWeightedGraph G, int v);
	std::vector<Edge> edges() const;
	double weight() const;
};

