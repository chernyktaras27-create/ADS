#pragma once
#include <vector>
#include <string>

class DirectedEdge
{
private:
	int mFrom;		// Startknoten
	int mTo;		// Endknoten
	double mWeight;	// Gewicht der Kante
public:
	DirectedEdge() 
		: mFrom{ 0 }
		, mTo{ 0 }
		, mWeight{ 0 }
	{}

	DirectedEdge(int from, int to, double weight)
		:mFrom{from}, 
		mTo{to},
		mWeight{ weight }
	{}

	double weight() const { return mWeight; }
	int from() const { return mFrom; }
	int to() const { return mTo; }
};

inline bool operator==(const DirectedEdge& lhs, const DirectedEdge& rhs) { return lhs.weight() == rhs.weight(); }
inline bool operator!=(const DirectedEdge& lhs, const DirectedEdge& rhs) { return !operator==(lhs, rhs); }
inline bool operator< (const DirectedEdge& lhs, const DirectedEdge& rhs) { return lhs.weight() < rhs.weight(); }
inline bool operator> (const DirectedEdge& lhs, const DirectedEdge& rhs) { return  operator< (rhs, lhs); }
inline bool operator<=(const DirectedEdge& lhs, const DirectedEdge& rhs) { return !operator> (lhs, rhs); }
inline bool operator>=(const DirectedEdge& lhs, const DirectedEdge& rhs) { return !operator< (lhs, rhs); }

class EdgeWeightedDigraph {
private:
	int mV;	 												// Anzahl Knoten von G
	int mE;													// Anzahl Kanten von G
	std::vector<std::vector<DirectedEdge>> mAdj;				// Adjazenzliste
	bool validateVertex(int v) const;
	void validateVertexWithError(int v) const;
public:
	EdgeWeightedDigraph(int V);								// Leeren Digraphen mit v Knoten erstellen
	EdgeWeightedDigraph(std::string filename);				// Graph einlesen aus Textdatei
	void add(DirectedEdge e);								// gerichtete Kante hinzuf�gen
	int getV() const;										// liefert Anzahl Knoten	
	int getE() const;										// liefert Anzahl der Kanten
	std::vector<std::vector<DirectedEdge>> getAdj() const;	// liefert die gestamte Kantenliste
	std::vector<DirectedEdge> getAdj(int v) const;			// liefert Array der adjazenten Kanten zu v
	std::vector<DirectedEdge> edges() const;				// alle Kanten dieses Graphen
	const std::vector<DirectedEdge> operator[](int v) const;
	bool delEdge(DirectedEdge e);							// L�scht eine Kante
};