#include "Graphsearch.h"
#include <iostream>
#include <queue>

namespace Graphsearch {

    void DFS_recursive(const EdgeWeightedGraph& G, int v, std::vector<bool>& marked, std::vector<int>& edgeTo) {
        marked[v] = true;
        std::cout << v << " ";

        for (Edge e : G.getAdj(v)) {
            int w = e.other(v);
            if (!marked[w]) {
                edgeTo[w] = v;
                DFS_recursive(G, w, marked, edgeTo);
            }
        }
    }

    bool DFS(const EdgeWeightedGraph& G, int v, std::vector<bool>& marked, std::vector<int>& edgeTo) {
        //  Löschen Sie das Array und stellen Sie die korrekte Arraygröße für den aktuellen Graphen ein.
        marked.assign(G.getV(), false);
        edgeTo.assign(G.getV(), -1);

        DFS_recursive(G, v, marked, edgeTo);
        std::cout << std::endl;

        for (int i = 0; i < G.getV(); ++i) {
            if (!marked[i]) return false; 
        }
        return true; 
    }

    bool BFS(const EdgeWeightedGraph& G, int v, std::vector<bool>& marked, std::vector<int>& edgeTo) {
        marked.assign(G.getV(), false);
        edgeTo.assign(G.getV(), -1);
        std::queue<int> q; 
        marked[v] = true;
        q.push(v);

        while (!q.empty()) {
            int current = q.front();
            q.pop();
            std::cout << current << " ";

            for (Edge e : G.getAdj(current)) {
                int w = e.other(current);
                if (!marked[w]) {
                    edgeTo[w] = current; 
                    marked[w] = true;    
                    q.push(w);           
                }
            }
        }
        std::cout << std::endl;

        for (int i = 0; i < G.getV(); ++i) {
            if (!marked[i]) return false;
        }
        return true;
    }
}