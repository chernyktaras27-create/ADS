#include "PrimMST.h"

/**
 * Erstellt einen MST zum Graph G mit dem Prim Algorithmus
 *
 * \param[in]  G		Kantengewichteter-Graph
 * \param[in]  s		Startknoten
 */
PrimMST::PrimMST(EdgeWeightedGraph G, int s)
{
	// Initialisiere das Array der besuchten Knoten
    mMarked.assign(G.getV(), false);
    
    // beginnen mit dem Startknoten.
    visit(G, s);

    // Hauptschleife: bis die Warteschlange leer ist
    while (!mPQ.empty()) {
        Edge e = mPQ.top(); // nehmen die günstigste Randkante.
        mPQ.pop();

        int v = e.either();
        int w = e.other(v);

        // Zyklusprüfung: Wenn beide Knoten bereits im Baum vorhanden sind – ignorieren
        if (mMarked[v] && mMarked[w]) {
            continue;
        }

        // Hinzufügen einer Kante zum minimalen Spannbaum
        mMST.push_back(e);

        // Besuche einen Knoten, der noch nicht im Baum vorhanden ist.
        if (!mMarked[v]) visit(G, v);
        if (!mMarked[w]) visit(G, w);
    }
}

/**
 * Markiert Knoten v im Graph G als markiert und fuegt alle Nachbarn zur mPQ hinzu
 *
 * \param[in]  G		Kantengewichteter-Graph
 * \param[in]  v		Knoten im Graph G
 */
void PrimMST::visit(EdgeWeightedGraph G, int v)
{
	// Markieren Sie den Knoten als Teil unseres Baums
    mMarked[v] = true;
    
    // Wir durchlaufen alle benachbarten Kanten.
    for (Edge e : G.getAdj(v)) {
        // Falls der Nachbarknoten noch nicht im Baum vorhanden ist, füge die Kante der Warteschlange hinzu.
        if (!mMarked[e.other(v)]) {
            mPQ.push(e);
        }
    }
}

/**
 * Gibt alle Kanten vom MST zurueck
 *
 * \return Vektor mit Kanten des MST
 */
std::vector<Edge> PrimMST::edges() const
{
	 return mMST;
}

/**
 * Gibt die Summe aller Gewichte im MST zurueck
 *
 * \return Summe der Gewichte im MST
 */
double PrimMST::weight() const
{
	double sum = 0.0;
    for (Edge e : mMST) {
        sum += e.weight();
    }
    return sum;
}
