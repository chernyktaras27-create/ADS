#include "EdgeWeightedGraph.h"
#include <fstream>
#include <assert.h>
#include <iostream>

/**
 * Erstellt einen Kantengewichteten-Gaph mit mV Knoten
 *
 * \param[in]  mV		Anzahl der Knoten
 */
EdgeWeightedGraph::EdgeWeightedGraph(int V)
	: mV{V}
	, mE{0}
{
	mAdj.resize(V);
}

/**
* Erstellt einen Kantengewichteten-Gaph anhand der Kantenliste in fname
*
* \param[in]  fname		Dateiname der Kantenliste
*/
EdgeWeightedGraph::EdgeWeightedGraph(std::string filename)
{
	std::ifstream infile(filename);
	int tmp_e = 0;
	infile >> this->mV >> tmp_e;

	this->mE = 0;

	this->mAdj.resize(this->mV, std::vector<Edge>());

	int v, w;
	double weight;
	while (infile >> v >> w >> weight)
	{
		this->add(Edge(v, w, weight));
	}

	assert(("Missing edges!", tmp_e == this->mE));
}
/**
 * Erstellt einen Kantengewichteten-Gaph mit mV Knoten und den Kanten in edges
 *
 * \param[in]  mV	Anzahl der Knoten
 * \param[in]  mE	Kantenliste
 */
EdgeWeightedGraph::EdgeWeightedGraph(int V, std::vector<Edge> E)
{
	this->mV = V;
	this->mAdj.resize(V);

	for (Edge e : E)
	{
		this->add(e);
	}
}

/**
 * Gibt zurueck ob der Knoten v ein gueltiger Knoten im Graph ist
 *
 * \param[in]  v		Knoten
 * \return Gueltigkeit des Knoten
 */
bool EdgeWeightedGraph::validateVertex(int v) const
{
	return v >= 0 && v < this->mV;
}

/**
 * Gibt eine Fehlermeldung aus, wenn der Knoten v im Graph nicht gueltig ist
 *
 * \param[in]  v		Knoten
 */
void EdgeWeightedGraph::validateVertexWithError(int v) const
{
	assert(("Vertex is out of bounds!", this->validateVertex(v)));
}

/**
 * Gibt die Anzahl der Knoten zurueck
 *
 * \return Anzahl der Knoten
 */
int EdgeWeightedGraph::getV() const
{
	return this->mV;
}

/**
 * Gibt die Anzahl der Kanten zurueck
 *
 * \return Anzahl der Kanten
 */
int EdgeWeightedGraph::getE() const
{
	return this->mE;
}

/**
 * Fuegt die Kante e zum Graphen hinzu
 *
 * \param[in]  e	neue Kante
 */
void EdgeWeightedGraph::add(Edge e)
{
	this->validateVertexWithError(e.either());
	this->validateVertexWithError(e.other(e.either()));

	this->mAdj[e.either()].push_back(e);
	this->mAdj[e.other(e.either())].push_back(e);

	this->mE++;
}

/**
 * Liefert alle benachbarten Kanten zu v
 * 
 * \param[in] v Knoten von dem aus gesucht wird
 * \return Vektor mit allen benachbarten Kanten
 */
std::vector<Edge> EdgeWeightedGraph::getAdj(int v) const
{
	std::vector<Edge> neighbors;
	for (auto const& n : mAdj[v]) {
		neighbors.push_back(n);
	}
	return neighbors;
}

std::vector<std::vector<Edge>> EdgeWeightedGraph::getAdj() const
{
	return this->mAdj;
}

/**
 * Gibt alle Kanten im Graph zurueck
 *
 * \return Vektor mit allen Kanten im Graph
 */
std::vector<Edge> EdgeWeightedGraph::edges() const
{
	std::vector<Edge> edgeList;
	for (int v = 0; v < this->mV; v++)
	{
		int selfLoops = 0;
		for (Edge e : this->mAdj[v])
		{
			if (e.other(v) > v) {
				edgeList.push_back(e);
			}
			// add only one copy of each self loop (self loops will be consecutive)
			else if (e.other(v) == v) {
				if (selfLoops % 2 == 0) edgeList.push_back(e);
				selfLoops++;
			}
		}
	}
	return edgeList;
}
/**
 * Gibt die verbunden Knoten eines Knoten v zurueck
 *
 * \param[in]  v		Knoten
 * \return Verbundene Knoten des Knoten v
 */
const std::vector<Edge> EdgeWeightedGraph::operator[](int v) const
{
	this->validateVertexWithError(v);
	return this->mAdj[v];
}

bool EdgeWeightedGraph::delEdge(Edge e)
{
	int v = e.either();
    int w = e.other(v);
    bool found = false;

    // In einer  Schleife suchen wir nach dem Knoten v in der Liste und entfernen ihn.
    for (int i = 0; i < mAdj[v].size(); i++) {
        if (mAdj[v][i] == e) {
            mAdj[v].erase(mAdj[v].begin() + i);
            found = true;
            break; // Знайшли і видалили, зупиняємо цикл
        }
    }

    // Wenn die Kante gar nicht im Graphen vorhanden war, geben wir einfach false zurück.
    if (!found) {
        return false;
    }

    // In einer  Schleife suchen wir nach einer Kopie des Knotens w in der Liste und entfernen diese.
    for (int i = 0; i < mAdj[w].size(); i++) {
        if (mAdj[w][i] == e) {
            mAdj[w].erase(mAdj[w].begin() + i);
            break;
        }
    }

    mE--; // Verringere die Gesamtzahl der Kanten
    return true;
}




