#pragma once
#include "EdgeWeightedDigraph.h"
#include "EdgeWeightedGraph.h"
#include <iostream>
#include <queue>

namespace Graphsearch {
	/**
		* Fuehrt eine rekursive Tiefensuche im Graphen G,
		* ab dem Knoten v aus und markiert alle besuchten
		* Knoten in mMarked.
		* Alle besuchten Knoten werdeb ausgegeben.
		*
		* \param[in]	 G		Graph
		* \param[in]	 v		Startknoten
		* \param[in/out] mMarked	Bereits besuchte Knoten
		* \param[in/out] mEdgeTo	Vektor mit dem vorherigen Knoten zu jedem Knoten
		*/
	void DFS_recursive(const EdgeWeightedGraph& G, int v, std::vector<bool>& marked, std::vector<int>& edgeTo);

	/**
		* Fuehrt eine rekursive Tiefensuche im Graphen g, ab dem Knoten v aus.
		* Alle besuchten Knoten werden ausgegeben.
		* Starterfunktion zu DFS(Graph, int, std::vector<bool>, int)
		*
		* \param[in]  G		Graph
		* \param[in/out] mMarked	Bereits besuchte Knoten
		* \param[in/out] mEdgeTo	Vektor mit dem vorherigen Knoten zu jedem Knoten
		* \param[in]  v		Startknoten
		* \return	  true  Graph ist zusammenhaengend
		*			  false Graph ist nicht zusammenhaengend
		*/

	bool DFS(const EdgeWeightedGraph& G, int v, std::vector<bool>& marked, std::vector<int>& edgeTo);

	/**
		* Fuehrt eine iterative Breitensuche im Graphen g, ab dem Knoten v aus.
		* Alle besuchten Knoten werden ausgegeben.
		*
		* \param[in]  G			Graph
		* \param[in]  v			Startknoten
		* \param[out] mMarked	Gibt an welche Knoten besucht wurden bei der Suche
		* \param[out] mEdgeTo	Gibt den vorherigen Knoten eines Knoten an
		* \return	  true  Graph ist zusammenhaengend
		*			  false Graph ist nicht zusammenhaengend
		*/
	bool BFS(const EdgeWeightedGraph& G, int v, std::vector<bool>& marked, std::vector<int>& edgeTo);
}
