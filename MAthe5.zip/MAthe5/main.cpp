#include <iostream>
#include <ctime>
#include "CZufall.h"

using namespace std;

void poker_simulation(int N) {
    CZufall z;
    // Ініціалізуємо генератор лише ОДИН РАЗ на початку!
    z.initialisiere(time(NULL)); 

    int count_zwei_paare = 0;
    int count_drilling = 0;

    for (int i = 0; i < N; i++) {
        // Створюємо колоду з 52 карт
        vector<int> deck;
        for (int k = 0; k < 52; k++) {
            deck.push_back(k);
        }

        vector<int> hand; // Наші 7 карт
        
        // 1. Витягуємо 7 карт без повторень
        for (int k = 0; k < 7; k++) {
            // Випадковий індекс з тих карт, що залишилися в колоді
            int index = z.wert(0, deck.size() - 1);
            hand.push_back(deck[index]);
            // Видаляємо витягнуту карту з колоди
            deck.erase(deck.begin() + index); 
        }

        // 2. Рахуємо, скільки разів випало кожне значення (від 0 до 12)
        vector<int> werte_count(13, 0);
        for (int k = 0; k < 7; k++) {
            int wert = hand[k] / 4; // Отримуємо значення карти
            werte_count[wert]++;
        }

        // 3. Оцінюємо комбінацію
        int paare = 0;
        bool has_drilling = false;

        for (int w = 0; w < 13; w++) {
            if (werte_count[w] >= 3) {
                has_drilling = true;
            }
            // Якщо значення випало 2 або більше разів - це пара
            if (werte_count[w] >= 2) {
                paare++;
            }
        }

        // Записуємо успіхи
        if (has_drilling) {
            count_drilling++;
        }
        if (paare >= 2) {
            count_zwei_paare++;
        }
    }

    // 4. Виводимо результати
    cout << "\n POKER SIMULATION (Monte-Carlo)" << endl;
    cout << "Gespielte Runden (N): " << N << endl;
    cout << "Zwei Paare: " << count_zwei_paare << " mal (" 
         << (double)count_zwei_paare / N * 100.0 << " %)" << endl;
    cout << "Drilling:   " << count_drilling << " mal (" 
         << (double)count_drilling / N * 100.0 << " %)" << endl;
}

int main() {
    CZufall z;
    int N = 10000;
    int a = 3, b = 7;

    cout << "a) Gleicher Seed (s=42) mehrfach" << endl;
    z.initialisiere(42);
    z.test(a, b, N);
    cout << "Nochmal mit s=42: " << endl;
    z.initialisiere(42);
    z.test(a, b, N);

    cout << "\n b) Verschiedene Seeds (s=42, dann s=99) " << endl;
    z.initialisiere(42);
    z.test(a, b, N);
    cout << "Nun mit s=99: " << endl;
    z.initialisiere(99);
    z.test(a, b, N);

    cout << "\nc) Initialisierung mit time(NULL) mehrfach " << endl;
    z.initialisiere(time(NULL));
    z.test(a, b, N);
    cout << " Nochmal time(NULL) (fast gleichzeitig): " << endl;
    z.initialisiere(time(NULL));
    z.test(a, b, N);

    cout << "\n d) test_falsch (time(NULL) im Loop) " << endl;
    z.test_falsch(a, b, N);

      // Запуск Завдання 2 (Рекомендую 100 000 або 1 000 000 ітерацій для точності)
    poker_simulation(1000000);
    

    system("pause");
    return 0;
}