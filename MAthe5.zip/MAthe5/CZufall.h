#pragma once
#include <vector>

class CZufall {
public:
    // Повертає випадкове число від a до b (включно)
    int wert(int a, int b);
    
    // Ініціалізує генератор випадкових чисел зерном s
    void initialisiere(int s);
    
    // Тестує генератор N разів і виводить частоту випадіння чисел
    void test(int a, int b, int N);
    
    // Робить те саме, але з навмисною помилкою (ініціалізація всередині циклу)
    void test_falsch(int a, int b, int N);
};