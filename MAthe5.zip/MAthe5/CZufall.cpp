#include "CZufall.h"
#include <iostream>
#include <cstdlib> // Потрібно для rand() та srand() [1]
#include <ctime>   // Потрібно для time() [2]

using namespace std;

// Метод генерації випадкового числа в діапазоні [a, b]
int CZufall::wert(int a, int b) {
    // rand() генерує число від 0 до RAND_MAX.
    // % (b - a + 1) обмежує його від 0 до довжини діапазону.
    // + a зсуває діапазон так, щоб він починався з a.
    return a + rand() % (b - a + 1); // [1]
}

// Метод ініціалізації генератора
void CZufall::initialisiere(int s) {
    srand(s); // [1]
}

// Правильний тест
void CZufall::test(int a, int b, int N) {
    // Створюємо вектор для підрахунку частоти. Розмір = кількість чисел у діапазоні.
    // Заповнюємо його нулями.
    vector<int> haeufigkeit(b - a + 1, 0);

    for (int i = 0; i < N; i++) {
        int z = wert(a, b);
        // Зсуваємо індекс на 'a', щоб число 'a' записувалось у 0-й елемент масиву
        haeufigkeit[z - a]++; 
    }

    // Вивід результатів
    for (int i = 0; i <= b - a; i++) {
        cout << "Wert " << (i + a) << ": " << haeufigkeit[i] << " mal\n";
    }
}

// Тест із навмисною помилкою
void CZufall::test_falsch(int a, int b, int N) {
    vector<int> haeufigkeit(b - a + 1, 0);

    for (int i = 0; i < N; i++) {
        // ПОМИЛКА: Ініціалізація всередині циклу перед кожним викликом [2]
        initialisiere(time(NULL)); 
        int z = wert(a, b);
        haeufigkeit[z - a]++;
    }

    for (int i = 0; i <= b - a; i++) {
        cout << "Wert " << (i + a) << ": " << haeufigkeit[i] << " mal\n";
    }
}