#pragma once

#include "CMyVektor.h"
#include <vector>

class CMyMatrix {
private:
    int rows;                    // Anzahl der Zeilen
    int cols;                    // Anzahl der Spalten
    std::vector<double> data;    // Matrixeinträge

public:
    // Konstruktor
    CMyMatrix(int m, int n);

    // Getter für Dimensionen
    int getRows() const;
    int getCols() const;

    // Zugriff auf Elemente
    void set(int i, int j, double value);
    double get(int i, int j) const;

    // Inverse (nur für 2x2)
    CMyMatrix invers() const;
};

// Matrix-Vektor-Multiplikation
CMyVektor operator*(CMyMatrix A, CMyVektor x);
CMyMatrix jacobi(CMyVektor x, CMyVektor (*funktion)(CMyVektor x));
CMyVektor newton(CMyVektor x,CMyVektor (*funktion)(CMyVektor)
);