#include "CMyVektor.h"
#include <cmath>
#include <iostream>
#include <stdexcept>
using namespace std;

//Konstructor
CMyVektor::CMyVektor(int n) : data(n) {}

// 
int CMyVektor::size() const {
    return data.size();
}

// set
void CMyVektor::set(int i, double value) {
    data[i] = value;
}

// get
double CMyVektor::get(int i) const {
    return data[i];
}

// operator[]
double& CMyVektor::operator[](int i) {
    return data[i];
}

double CMyVektor::operator[](int i) const {
    return data[i];
}
double mySqrt(double x) {
    if (x == 0) return 0;

    double y = x;

    for (int i = 0; i < 20; i++) {
        y = 0.5 * (y + x / y);
    }

    return y;
}


double CMyVektor::length() const {
    double sum = 0.0;

    for (int i = 0; i < data.size(); i++) {
        sum += data[i] * data[i];
    }

    return sqrt(sum);
}

CMyVektor operator+(const CMyVektor& a, const CMyVektor& b) {

    if (a.size() != b.size()) {
        //CMyVektor result(0);
        //return result;
        throw std::invalid_argument("Vector sizes are not equal");
    }

    int n = a.size();
    CMyVektor result(n);

    for (int i = 0; i < n; i++) {
        result[i] = a[i] + b[i];
    }

    return result;
}
CMyVektor operator*(double lambda, const CMyVektor& a) {

    int n = a.size();
    CMyVektor result(n);

    for (int i = 0; i < n; i++) {
        result[i] = lambda * a[i];
    }

    return result;
}

CMyVektor gradient(CMyVektor x,double (*funktion)(CMyVektor x)) {
    double h = 1e-8;
    int n = x.size();
    CMyVektor grad(n);
    double fx = funktion(x);  // f(x)
    for (int i = 0; i < n; i++) {
        CMyVektor x_mod = x;   // kopie
        x_mod[i] = x_mod[i] + h;
        double fxh = funktion(x_mod);
        grad[i] = (fxh - fx) / h;
    }
    return grad;
}

CMyVektor gradientMax(
    CMyVektor x,
    double (*funktion)(CMyVektor),
    double lambda
) {
    int maxSteps = 50;

    for (int step = 0; step < maxSteps; step++) {

        CMyVektor grad = gradient(x, funktion);
        double gradLen = grad.length();
        double fx = funktion(x);

        // ausgabe
        cout << "Schritt " << step << ":\n";
        cout << "\t x = ( ";
        for (int i = 0; i < x.size(); i++) {
            cout << x[i];
            if (i < x.size() - 1) cout << "; ";
        }
        cout << " )\n";

        cout << "\t lambda = " << lambda << "\n";
        cout << "\t f(x) = " << fx << "\n";

        cout << "\t grad f(x) = ( ";
        for (int i = 0; i < grad.size(); i++) {
            cout << grad[i];
            if (i < grad.size() - 1) cout << "; ";
        }
        cout << " )\n";

        cout << "\t ||grad f(x)|| = " << gradLen << "\n\n";

        // Abbruchbedingung
        if (gradLen < 1e-5) {
            cout << "Ende wegen ||grad f(x)||<1e-5 bei \n";
            break;
        }

        // Probeschritt
        CMyVektor x_new = x + lambda * grad;
        double f_new = funktion(x_new);

        cout << "\t x_neu = ( ";
        for (int i = 0; i < x_new.size(); i++) {
            cout << x_new[i];
            if (i < x_new.size() - 1) cout << "; ";
        }
        cout << " )\n";

        cout << "\t f(x_neu) = " << f_new << "\n\n";

        // Wenn es schlimmer wird dann durch λ teilen
        while (f_new <= fx) {
            lambda = lambda / 2;

            cout << "\t halbiere Schrittweite (lambda = " << lambda << "):\n";

            x_new = x + lambda * grad;
            f_new = funktion(x_new);

            cout << "\t x_neu = ( ";
            for (int i = 0; i < x_new.size(); i++) {
                cout << x_new[i];
                if (i < x_new.size() - 1) cout << "; ";
            }
            cout << " )\n";

            cout << "\t f(x_neu) = " << f_new << "\n\n";
        }

        // Wenn es besser wird → versuchen Sie es mit 2λ
        if (f_new > fx) {
            double lambda2 = 2 * lambda;
            CMyVektor x_test = x + lambda2 * grad;
            double f_test = funktion(x_test);

            cout << "\t Test mit doppelter Schrittweite (lambda = " << lambda2 << "):\n";

            cout << "\t x_test = ( ";
            for (int i = 0; i < x_test.size(); i++) {
                cout << x_test[i];
                if (i < x_test.size() - 1) cout << "; ";
            }
            cout << " )\n";

            cout << "\t f(x_test) = " << f_test << "\n";

            if (f_test > f_new) {
                cout << "\t verdoppele Schrittweite!\n\n";
                lambda = lambda2;
                x = x_test;
            } else {
                cout << "\t behalte alte Schrittweite!\n\n";
                x = x_new;
            }
        }
    }

    return x;
}
double parabola(CMyVektor x) {
    double a = x[0];
    double b = x[1];
    double c = x[2];

    double xi[7] = {-1.5, -1, -0.5, 0, 0.5, 1, 1.5};

    double yi[7] = {0.5, 0.7, 0.3, 0.5, -0.2, -0.2, -1.3};

    double s = 0.0;

    for (int i = 0; i < 7; i++) {
        double fx = a * xi[i] * xi[i] + b * xi[i] + c;
        double diff = fx - yi[i];
        s += diff * diff;
    }

    return -s; // 
}