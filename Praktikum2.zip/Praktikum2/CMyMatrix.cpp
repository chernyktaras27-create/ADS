#include "CMyMatrix.h"
#include <iostream>
using namespace std;

// Konstruktor
CMyMatrix::CMyMatrix(int m, int n) {
    rows = m;
    cols = n;
    data.resize(m * n);
}

// Dimensionen
int CMyMatrix::getRows() const {
    return rows;
}

int CMyMatrix::getCols() const {
    return cols;
}

// Setzen eines Elements
void CMyMatrix::set(int i, int j, double value) {
    data[i * cols + j] = value;
}

// Lesen eines Elements
double CMyMatrix::get(int i, int j) const {
    return data[i * cols + j];
}

// Inverse für 2x2 Matrix
CMyMatrix CMyMatrix::invers() const {

    if (rows != 2 || cols != 2) {
        cout << "Fehler: Inverse nur für 2x2 Matrizen!" << endl;
        exit(1);
    }

    double a = get(0, 0);
    double b = get(0, 1);
    double c = get(1, 0);
    double d = get(1, 1);

    double det = a * d - b * c;

    if (det == 0) {
        cout << "Fehler: Determinante ist 0!" << endl;
        exit(1);
    }

    CMyMatrix inv(2, 2);

    inv.set(0, 0,  d / det);
    inv.set(0, 1, -b / det);
    inv.set(1, 0, -c / det);
    inv.set(1, 1,  a / det);

    return inv;
}

// Matrix-Vektor-Multiplikation
CMyVektor operator*(CMyMatrix A, CMyVektor x) {

    if (A.getCols() != x.size()) {
        cout << "Fehler: Dimensionen passen nicht!" << endl;
        exit(1);
    }

    CMyVektor result(A.getRows());

    for (int i = 0; i < A.getRows(); i++) {
        double sum = 0;

        for (int j = 0; j < A.getCols(); j++) {
            sum += A.get(i, j) * x[j];
        }

        result[i] = sum;
    }

    return result;
}

CMyMatrix jacobi(CMyVektor x, CMyVektor (*funktion)(CMyVektor)) {

    double h = 1e-4;

    CMyVektor fx = funktion(x);

    int m = x.size();     // Anzahl Variablen
    int n = fx.size();    // Anzahl Funktionen

    CMyMatrix J(n, m);    // n x m Matrix

    for (int j = 0; j < m; j++) {

        CMyVektor x_h = x;
        x_h[j] += h;

        CMyVektor fx_h = funktion(x_h);

        for (int i = 0; i < n; i++) {

            double diff = (fx_h[i] - fx[i]) / h;
            J.set(i, j, diff);
        }
    }

    return J;
}

CMyVektor newton(CMyVektor x, CMyVektor (*f)(CMyVektor)) {

    int maxSteps = 50;

    for (int step = 0; step < maxSteps; step++) {

        CMyVektor fx = f(x);
        double norm = fx.length();

        cout << "Schritt " << step << ":\n";
        cout << "\t x = ( ";
        for (int i = 0; i < x.size(); i++) {
            cout << x[i];
            if (i < x.size() - 1) cout << "; ";
        }
        cout << " )\n";

        cout << "\t f(x) = ( ";
        for (int i = 0; i < fx.size(); i++) {
            cout << fx[i];
            if (i < fx.size() - 1) cout << "; ";
        }
        cout << " )\n";

        cout << "\t ||f(x)|| = " << norm << "\n\n";

        // Stop VOR EINEM NEUEN SCHRITT 
        if (norm < 1e-5) {
            cout << "Ende wegen ||f(x)||<1e-5 bei \n";
            cout << "\t x = ( ";
            for (int i = 0; i < x.size(); i++) {
                cout << x[i];
                if (i < x.size() - 1) cout << "; ";
            }
            cout << " )\n";

            cout << "\t f(x) = ( ";
            for (int i = 0; i < fx.size(); i++) {
                cout << fx[i];
                if (i < fx.size() - 1) cout << "; ";
            }
            cout << " )\n";

            cout << "\t ||f(x)|| = " << norm << "\n";

            return x;
        }

        // Jacobian + inverse
        CMyMatrix J = jacobi(x, f);
        CMyMatrix Jinv = J.invers();

        CMyVektor dx = Jinv * fx;

        // Newton update
        for (int i = 0; i < x.size(); i++) {
            x[i] = x[i] - dx[i];
        }
    }

    cout << "Ende wegen Schrittanzahl\n";
    return x;
}