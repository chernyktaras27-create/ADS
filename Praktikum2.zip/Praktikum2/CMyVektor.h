#pragma once

#include <vector>

class CMyVektor {
private:
    std::vector<double> data;

public:
    CMyVektor(int n);  

    int size() const;
    void set(int i, double value);
    double get(int i) const;

    double& operator[](int i);
    double operator[](int i) const;

    double length() const;
};

CMyVektor operator+(const CMyVektor& a, const CMyVektor& b);
CMyVektor operator*(double lambda, const CMyVektor& a);
CMyVektor gradient(CMyVektor x,double (*funktion)(CMyVektor x));
CMyVektor gradientMax( CMyVektor x,double (*funktion)(CMyVektor),double lambda = 1.0);
double parabola(CMyVektor x);