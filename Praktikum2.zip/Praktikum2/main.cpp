#include <iostream>
using namespace std;
#include "CMyVektor.h"
#include <cmath>
#include "CMyMatrix.h"
#include <iomanip>
CMyVektor funktion(CMyVektor x) {

    CMyVektor result(3);

    double x1 = x[0];
    double x2 = x[1];
    double x3 = x[2];
    double x4 = x[3];

    result[0] = x1 * x2 * exp(x3);
    result[1] = x2 * x3 * x4;
    result[2] = x4;

    return result;
}

CMyVektor funktion2(CMyVektor x) {

    CMyVektor result(2);

    double a = x[0];
    double b = x[1];

    result[0] = a*a*a * b*b*b - 2*b;
    result[1] = a - 2;

    return result;
}
int main() {
    /** CMyVektor x(4);

    x[0] = 1;
    x[1] = 2;
    x[2] = 0;
    x[3] = 3;

    CMyMatrix J = jacobi(x, funktion);

    cout << "Jacobi-Matrix:\n";
    cout << fixed << setprecision(6);

    cout << "( ";
for (int i = 0; i < J.getRows(); i++) {

    for (int j = 0; j < J.getCols(); j++) {
        cout << J.get(i, j);
        if (j < J.getCols() - 1) cout << "; ";
    }

    if (i < J.getRows() - 1)
        cout << "\n  ";
}
cout << " )\n";*/


CMyVektor x(2);

    x[0] = 1;
    x[1] = 1;

    CMyVektor result = newton(x, funktion2);

    


    system("pause");
    return 0;
}