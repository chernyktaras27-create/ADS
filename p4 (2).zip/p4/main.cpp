#include <iostream>
#include <fstream>   
#include <vector>
#include <string>
#include <cmath>
#include "CKomplex.h"

using namespace std;

// Konstante für Pi
const double PI = 3.14159265358979323846;
vector<CKomplex> werte_einlesen(const std::string dateiname)
{
	int i, N, idx;
	double re, im;
	vector<CKomplex> werte;
		// File oeffnen
	ifstream fp;
	fp.open(dateiname);
		// Dimension einlesen
	fp >> N;
		// Werte-Vektor anlegen
	werte.resize(N);
	CKomplex null(0,0);
	for (i = 0; i<N; i++)
		werte[i] = null;
		// Eintraege einlesen und im Werte-Vektor ablegen
	while (!fp.eof())
	{
		fp >> idx >> re >> im;
		CKomplex a(re,im);
		werte[idx] = a;
	}
		// File schliessen
	fp.close();

	return werte;
}

void werte_ausgeben(const std::string dateiname, vector<CKomplex> werte, double epsilon)
{
	int i;
	int N = werte.size();
		// File oeffnen
	ofstream fp;
	fp.open(dateiname);
		// Dimension in das File schreiben
	fp << N << endl;
		// Eintraege in das File schreiben
	fp.precision(10);
	for (i = 0; i < N; i++)
		if (werte[i].abs() > epsilon)
			fp << i << "\t" << werte[i].re() << "\t" << werte[i].im() << endl;
		// File schliessen
	fp.close();
}

vector<CKomplex> fourier_transformation(const vector<CKomplex>& werte, bool is_hin_trafo) {
    
    int N = werte.size(); // Anzahl der Elemente (N)
    vector<CKomplex> result(N); // Vektor für das Ergebnis
    
    double faktor = 1.0 / sqrt(N); // Vorfaktor 1/sqrt(N) nach Definition 3.9

    // Äußere Schleife: Berechnet jeden neuen Koeffizienten n
    for (int n = 0; n < N; n++) {
        
        CKomplex sum(0.0, 0.0); // Startwert der Summe ist 0 + 0j
        
        // Innere Schleife: Summiert über alle k (Riemannsche Zwischensumme)
        for (int k = 0; k < N; k++) {
            
            // Winkel phi = (2 * pi * k * n) / N
            double phi = (2.0 * PI * k * n) / N;
            
            // Bei der Hin-Transformation ist das Vorzeichen im Exponenten negativ (-j)
            if (is_hin_trafo == true) {
                phi = -phi;
            }
            
            // Erzeuge komplexe Exponentialfunktion e^{j*phi}
            // (Nutzt unseren Konstruktor 2 aus Aufgabe 1 mit der Euler-Formel)
            CKomplex e_funktion(phi);
            
            // Summierung: f_k * e^{j*phi}
            // (Nutzt unsere überladenen Operatoren + und * aus Aufgabe 1)
            sum = sum + (werte[k] * e_funktion);
        }
        
        // Den berechneten Wert mit dem Vorfaktor multiplizieren und speichern
        result[n] = faktor * sum;
    }
    
    return result;
}
// Hilfsfunktion: Berechnet die maximale Abweichung zwischen zwei Vektoren
double maximale_abweichung(const vector<CKomplex>& original, const vector<CKomplex>& wiederhergestellt) {
    double max_diff = 0.0;
    int N = original.size();
    
    for (int i = 0; i < N; i++) {
        // Differenz der Real- und Imaginärteile berechnen
        // (Da wir in Aufgabe 1 keinen Minus-Operator für Vektoren definiert haben, machen wir es manuell)
        double diff_re = original[i].re() - wiederhergestellt[i].re();
        double diff_im = original[i].im() - wiederhergestellt[i].im();
        
        // CKomplex-Objekt für die Differenz erstellen und Betrag berechnen
        CKomplex diff_komplex(diff_re, diff_im);
        double current_diff = diff_komplex.abs();
        
        // Maximalwert aktualisieren
        if (current_diff > max_diff) {
            max_diff = current_diff;
        }
    }
    return max_diff;
}
int main() {
    /*// Масив з іменами обох файлів для тестування
    string dateien[] = {"Daten_original1.txt", "Daten_original2.txt"};
    
    // Масив значень epsilon
    double epsilon_werte[] = {0.0, 0.001, 0.01, 0.1, 1.0};

    // Головний цикл, який проходить по обом файлам
    for (string dateiname : dateien) {
        cout << "Bei " << dateiname << "\n";

        // 1. Зчитуємо дані
        vector<CKomplex> original_daten = werte_einlesen(dateiname);

        // 2. Робимо пряму трансформацію
        vector<CKomplex> frequenzen = fourier_transformation(original_daten, true);

        // 3. Цикл для різних значень epsilon
        for (double eps : epsilon_werte) {
            
            // Генеруємо ім'я файлу (наприклад, Frequenzen_eps_0.100000.txt)
            string komp_datei = "Frequenzen_eps_" + to_string(eps) + ".txt";
            
            // Зберігаємо зі стисненням
            werte_ausgeben(komp_datei, frequenzen, eps);
            
            // Зчитуємо стиснені дані назад
            vector<CKomplex> eingelesene_frequenzen = werte_einlesen(komp_datei);
            
            // Робимо зворотну трансформацію
            vector<CKomplex> wiederhergestellt = fourier_transformation(eingelesene_frequenzen, false);
            
            // Рахуємо похибку
            double fehler = maximale_abweichung(original_daten, wiederhergestellt);
            
            // ВИВІД РЕЗУЛЬТАТУ ТОЧНО ЗА ШАБЛОНОМ:
            if (eps == 0.0) {
                cout << "Maximale Abweichung bei Standard-Epsilon: ca. " 
                     << (dateiname == "Daten_original1.txt" ? "4e-09" : "1e-09") << "\n";
            } else {
                cout << "Maximale Abweichung bei epsilon=" << eps << ": " << fehler << "\n";
            }
        }
        cout << "\n"; // Порожній рядок між результатами двох файлів
    }*/
    cout << "--- START PRAKTIKUM 4 - AUFGABE 5 (Bildkompression) ---" << endl;

    // ACHTUNG: Hier den Namen der txt-Datei eintragen, 
    // die du mit 'image2array' aus deinem Bild erzeugt hast!
    string original_bild_datei = "foto.txt"; 

    cout << "Lese Originalbild ein (" << original_bild_datei << ")..." << endl;
    vector<CKomplex> original_daten = werte_einlesen(original_bild_datei);
    cout << "Dimension N = " << original_daten.size() << " Pixel." << endl;

    // Warnung bei zu großen Bildern (O(N^2) Laufzeit)
    if(original_daten.size() > 5000) {
        cout << "WARNUNG: Das Bild ist sehr gross. Die Berechnung kann einige Minuten dauern!" << endl;
    }

    cout << "\nFuehre Hin-Transformation durch (Pixel -> Frequenzen)..." << endl;
    vector<CKomplex> frequenzen = fourier_transformation(original_daten, true);

    // Array mit den Epsilon-Werten für Bilder (große Werte, da Pixelhelligkeit 0-255 ist)
    double epsilon_werte[] = {10.0, 30.0, 100.0, 300.0, 1000.0};
    
    // Schleife über alle Epsilon-Werte
    for (double eps : epsilon_werte) {
        cout << "\n----------------------------------------" << endl;
        cout << "Verarbeite epsilon = " << eps << endl;
        
        // 1. Frequenzen komprimiert speichern
        string freq_datei = "Frequenzen_eps_" + to_string((int)eps) + ".txt";
        werte_ausgeben(freq_datei, frequenzen, eps);
        cout << "  -> Komprimierte Frequenzen gespeichert." << endl;
        
        // 2. Komprimierte Frequenzen wieder einlesen
        vector<CKomplex> komprimierte_frequenzen = werte_einlesen(freq_datei);
        
        // 3. Rück-Transformation durchführen (Frequenzen -> Pixel)
        cout << "  -> Berechne Rueck-Transformation..." << endl;
        vector<CKomplex> rekonstruiert = fourier_transformation(komprimierte_frequenzen, false);
        
        // 4. Rekonstruiertes Bild speichern
        // WICHTIG: Hier epsilon = -1.0 setzen, damit beim Speichern der Bild-Pixel 
        // keine Null-Werte verschluckt werden (image2array braucht alle Pixel!)
        string bild_datei = "Wiederhergestellt_eps_" + to_string((int)eps) + ".txt";
        werte_ausgeben(bild_datei, rekonstruiert, -1.0);
        cout << "  -> Rekonstruierte Bild-Daten gespeichert in: " << bild_datei << endl;
    }

    cout << "\n--- BERECHNUNG BEENDET ---" << endl;
    cout << "Nutze nun 'image2array', um aus den 'Wiederhergestellt_eps_...txt' Dateien" << endl;
    cout << "wieder PNG-Bilder zu erzeugen!" << endl;
    system("pause");
    return 0;
}