#include "CKomplex.h"

// Konstruktor 1: Algebraische Form (z = a + bj)
CKomplex::CKomplex(double a, double b) {
    real = a;
    imag = b;
}

// Konstruktor 2: Exponentialform (z = e^{j*phi})
// Nutzt die Eulersche Formel: e^{j*phi} = cos(phi) + j*sin(phi)
CKomplex::CKomplex(double phi) {
    real = std::cos(phi);
    imag = std::sin(phi);
}

// Default-Konstruktor: Initialisiert mit 0 + 0j
CKomplex::CKomplex() {
    real = 0.0;
    imag = 0.0;
}

// Gibt den Realteil zurück
double CKomplex::re() const {
    return real;
}

// Gibt den Imaginärteil zurück
double CKomplex::im() const{
    return imag;
}

// Berechnet den Betrag der komplexen Zahl (Satz des Pythagoras)
// |z| = sqrt(a^2 + b^2)
double CKomplex::abs() const {
    return std::sqrt(real * real + imag * imag);
}

// --- Überladene Operatoren ---

// Addition: Real- und Imaginärteile werden separat addiert
CKomplex operator+(CKomplex a, CKomplex b) {
    return CKomplex(a.re() + b.re(), a.im() + b.im());
}

// Multiplikation von zwei komplexen Zahlen
// (a1 + b1*j) * (a2 + b2*j) = (a1*a2 - b1*b2) + (a1*b2 + a2*b1)*j
CKomplex operator*(CKomplex a, CKomplex b) {
    double neu_real = a.re() * b.re() - a.im() * b.im();
    double neu_imag = a.re() * b.im() + a.im() * b.re();
    return CKomplex(neu_real, neu_imag);
}

// Skalare Multiplikation: Eine reelle Zahl mal eine komplexe Zahl
// lambda * (a + b*j) = (lambda*a) + (lambda*b)*j
CKomplex operator*(double lambda, CKomplex a) {
    return CKomplex(lambda * a.re(), lambda * a.im());
}