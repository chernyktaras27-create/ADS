#pragma once
#include <cmath>

class CKomplex {
private:
    // Private Attribute für den Real- und Imaginärteil
    double real;
    double imag;

public:
    // Konstruktor für die Darstellung a + bj
    CKomplex(double a, double b);
    
    // Konstruktor zur Erzeugung von e^{j*phi}
    CKomplex(double phi);
    
    // Default-Konstruktor (nützlich für Arrays/Vektoren)
    CKomplex();

    // Öffentliche Methoden zur Rückgabe der Werte
    double re() const;
    double im()  const;

    // Methode, die den Betrag der komplexen Zahl zurückgibt
    double abs() const;
};

// Überladene Operatoren als globale Funktionen deklariert
// Addition von zwei komplexen Zahlen
CKomplex operator+(CKomplex a, CKomplex b);

// Multiplikation von zwei komplexen Zahlen
CKomplex operator*(CKomplex a, CKomplex b);

// Multiplikation einer double-Zahl mit einer komplexen Zahl
CKomplex operator*(double lambda, CKomplex a);