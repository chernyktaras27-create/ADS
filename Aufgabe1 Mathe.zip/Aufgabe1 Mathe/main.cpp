#include <iostream>
#include "CMyVektor.h"
#include <cmath>

using namespace std;
double f(CMyVektor x) {
    double x1 = x[0];
    double x2 = x[1];

    return sin(x1 * x2) + sin(x1) + cos(x2);
}

    
double g(CMyVektor x) {
    double x1 = x[0];
    double x2 = x[1];
    double x3 = x[2];

    return -(2*x1*x1 - 2*x1*x2 + x2*x2 + x3*x3 - 2*x1 - 4*x3);
}
int main() {
    /*CMyVektor a(3);
    CMyVektor b(3);

    // ausfüllen
    a[0] = 1;
    a[1] = 2;
    a[2] = 3;

    b[0] = 4;
    b[1] = 5;
    b[2] = 6;

    // addiren
    CMyVektor c = a + b;

    cout << "a + b = ";
    for (int i = 0; i < c.size(); i++) {
        cout << c[i] << " ";
    }
    cout << endl;

    // mult
    CMyVektor d = 2 * a;

    cout << "2 * a = ";
    for (int i = 0; i < d.size(); i++) {
        cout << d[i] << " ";
    }
    cout << endl;
    cout << "Length of a = " << a.length() << endl;*/
    /*CMyVektor x(2);
    x[0] = 0.2;
    x[1] = -2.1;

    gradientMax(x, f);*/
    /*CMyVektor x(3);

    x[0] = 0;
    x[1] = 0;
    x[2] = 0;
    gradientMax(x, g,0.1);*/
    CMyVektor x(3);

    x[0] = 0; // a
    x[1] = 0; // b
    x[2] = 0; // c

    gradientMax(x, parabola, 0.1);

    system("pause");
    return 0;
}