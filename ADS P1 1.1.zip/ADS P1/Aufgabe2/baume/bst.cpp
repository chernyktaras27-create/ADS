// ADS Praktikum 1.2 BST Musterl�sung
// Stand M�rz 2025
// Autor Carlhoff
#include <iostream>
#include "bst.h"
#include <queue>

/**
 * Start-Funktion zur Suche eines Integer-Zahlenwertes im Baum
 *
 * @param value Integer-Zahlenwert, der gesucht werden soll
 *
 */
Node *Bst::find(int value)
{
    Node *current = mRoot;
    while (current != nullptr){
        if (value == current->data){
            return current;
        }
        if (value < current->data){
            current = current->left;
        }
        else{
            current = current->right;
        }
    }
     return nullptr;
}

/**
 * Funktion zum Einf�gen eines Integer-Zahlenwertes in den Baum
 *
 * @param value Integer-Zahlenwert, der eingef�gt werden soll
 *
 */
void Bst::insert(int value)
{
    Node *newNode = new Node{value, 0, nullptr, nullptr};
    // Wenn der Baum leer ist
    if (mRoot == nullptr){
        mRoot = newNode;
        return;
    }

    Node *current = mRoot;
    Node *parent = nullptr;

    // Suche nach einem Einfügepunkt
    while (current != nullptr)
    {
        parent = current;
        if (value < current->data)
            current = current->left;
        else
            current = current->right;
    }

    // als Kind einfügen
    if (value < parent->data)
        parent->left = newNode;
    else
        parent->right = newNode;
}

void inorderPrint(Node *node)
{
    if (node == nullptr)
        return;
    inorderPrint(node->left);
    std::cout << node->data << " ";
    inorderPrint(node->right);
}
void Bst::inorder()
{
    inorderPrint(mRoot);
}


void preorderPrint(Node *node)
{
    if (node == nullptr)
        return;

    std::cout << node->data << " ";
    preorderPrint(node->left);
    preorderPrint(node->right);
}
void Bst::preorder()
{
    preorderPrint(mRoot);
}


void postorderPrint(Node *node)
{
    if (node == nullptr)
        return;
    postorderPrint(node->left);
    postorderPrint(node->right);
    std::cout << node->data << " ";
}
void Bst::postorder()
{
    postorderPrint(mRoot);
}



void levelorderPrint(Node *start)
{
    if (start == nullptr)
        return;
    std::queue<Node *> q;
    q.push(start);
    
    while (!q.empty())
    {
        Node *current = q.front();
        q.pop();
         std::cout << current->data << " ";
        if (current->left)
            q.push(current->left);
        if (current->right)
            q.push(current->right);
    }
}
void Bst::levelorder(Node *start)
{
    levelorderPrint(start);
}

/**
 * Start-Funktion zum L�schen eines Integer-Zahlenwertes im Baum
 *
 * @param value Integer-Zahlenwert, der gel�scht werden soll
 *
 */
Node *findMin(Node *node)
{
    while (node->left != nullptr)
        node = node->left;

    return node;
}
Node *deleteRec(Node *node, int value)
{
    if (node == nullptr)
        return nullptr;

    if (value < node->data)
    {
        node->left = deleteRec(node->left, value);
    }
    else if (value > node->data)
    {
        node->right = deleteRec(node->right, value);
    }
    else
    {
        // CASE 1: no children
        if (node->left == nullptr && node->right == nullptr)
        {
            delete node;
            return nullptr;
        }

        // CASE 2: one child
        else if (node->left == nullptr)
        {
            Node *temp = node->right;
            delete node;
            return temp;
        }
        else if (node->right == nullptr)
        {
            Node *temp = node->left;
            delete node;
            return temp;
        }

        // CASE 3: two children
        Node *temp = findMin(node->right);

        node->data = temp->data;

        node->right = deleteRec(node->right, temp->data);
    }

    return node;
}
void Bst::deleteValue(int value)
{
    mRoot = deleteRec(mRoot, value);
}

void Bst::updateHeight(Node *node)
{
    if (node == nullptr)
        return;

    int leftHeight = 0;
    int rightHeight = 0;

    if (node->left != nullptr)
        leftHeight = node->left->height;

    if (node->right != nullptr)
        rightHeight = node->right->height;

    node->height = 1 + std::max(leftHeight, rightHeight);
}