#include <iostream>
#include <queue>
#include <vector>
#include <stack>


#include "RedBlackBST.h"

RedBlackBST::RedBlackBST()
{
    mRoot = nullptr;
}

bool RedBlackBST::isRED(Node* x)
{
    if (x == nullptr)
        return false;
    return x->color == RED;
}

// mit Rueckgabe von Node*
Node* RedBlackBST::rotateLeft(Node* h)
{
    Node* x = h->right;
    h->right = x->left;
    x->left = h;
    
    // Ausgabe von Rotationsinformationen
    std::cout << "LR(" << h->key << "," << x->key << ")\n"; 
    return x; //  Gib die neue Wurzel des Teilbaums zurück.
}

Node* RedBlackBST::rotateRight(Node* h)
{
    Node* x = h->left;
    h->left = x->right;
    x->right = h;
    
    // Ausgabe von Rotationsinformationen
    std::cout << "RR(" << h->key << "," << x->key << ")\n"; 
    return x; // Gib die neue Wurzel des Teilbaums zurück.
}

void RedBlackBST::flipColors(Node* h)
{
    h->color         = RED;
    h->left->color   = BLACK;
    h->right->color = BLACK;
}

bool RedBlackBST::split4Node(Node* h)
{
    if (h == nullptr)
    {
        return false;
    }

    // Ein 4-Knoten:
    // schwarzer Vater mit zwei roten Kindern
    if (h->color == BLACK &&
        isRED(h->left) &&
        isRED(h->right))
    {
        flipColors(h);
        return true;
    }

    return false;
}
bool RedBlackBST::insert(int key)
{
    // Leerer Baum -> neue schwarze Wurzel
    if (mRoot == nullptr)
    {
        mRoot = new Node(key, key, 1, BLACK);
        return true;
    }

    std::stack<Node*> path;
    Node* curr = mRoot;

    // 1. Top-Down Traversierung + split 4-node
    while (curr != nullptr)
    {
        // 4-er Knoten auflösen (Top-Down)
        split4Node(curr);

        // Duplikate nicht erlaubt
        if (key == curr->key)
        {
            return false;
        }

        path.push(curr);

        curr = (key < curr->key) ? curr->left : curr->right;
    }

    // 2. Neues Blatt (immer rot)
    Node* parent = path.top();
    Node* newNode = new Node(key, key, 1, RED);

    if (key < parent->key)
    {
        parent->left = newNode;
    }
    else
    {
        parent->right = newNode;
    }

    // 3. Bottom-Up Korrektur (nur Rot-Rot Konflikte)
    Node* child = newNode;

    while (!path.empty())
    {
        Node* parent = path.top();
        path.pop();

        // Kein Rot-Rot -> fertig
        if (!isRED(parent) || !isRED(child))
        {
            child = parent;
            continue;
        }

        // Wenn kein Großvater existiert -> fertig
        if (path.empty())
        {
            break;
        }

        Node* grandparent = path.top();

        // -------------------------
        // Linksfall
        // -------------------------
        if (parent == grandparent->left)
        {
            // LR Fall
            if (child == parent->right)
            {
                grandparent->left = rotateLeft(parent);
                parent = grandparent->left;
            }

            // LL Fall
            Node* newSubRoot = rotateRight(grandparent);

            newSubRoot->color = BLACK;
            if (newSubRoot->right)
                newSubRoot->right->color = RED;

            // reconnect
            if (path.size() >= 2)
            {
                path.pop();
                Node* greatGrandparent = path.top();

                if (greatGrandparent->left == grandparent)
                    greatGrandparent->left = newSubRoot;
                else
                    greatGrandparent->right = newSubRoot;
            }
            else
            {
                mRoot = newSubRoot;
            }

            child = newSubRoot;
            continue;
        }

        // -------------------------
        // Rechtsfall
        // -------------------------
        else
        {
            // RL Fall
            if (child == parent->left)
            {
                grandparent->right = rotateRight(parent);
                parent = grandparent->right;
            }

            // RR Fall
            Node* newSubRoot = rotateLeft(grandparent);

            newSubRoot->color = BLACK;
            if (newSubRoot->left)
                newSubRoot->left->color = RED;

            // reconnect
            if (path.size() >= 2)
            {
                path.pop();
                Node* greatGrandparent = path.top();

                if (greatGrandparent->left == grandparent)
                    greatGrandparent->left = newSubRoot;
                else
                    greatGrandparent->right = newSubRoot;
            }
            else
            {
                mRoot = newSubRoot;
            }

            child = newSubRoot;
            continue;
        }
    }

    // 4. Root immer schwarz
    mRoot->color = BLACK;

    return true;
}

int RedBlackBST::size()
{
    return size(mRoot);
}

int RedBlackBST::size(Node* h)
{
    if (h == nullptr)
        return 0;
    else
        return h->N;
}


void RedBlackBST::print() {
    if (mRoot == nullptr) return;

    std::queue<Node*> qNodes;
    std::queue<int> qLevels;

    // Починаємо з кореня (він завжди чорний) на рівні 0
    qNodes.push(mRoot);
    qLevels.push(0);

    int currentLevel = -1;

    while (!qNodes.empty()) {
        Node* curr = qNodes.front(); qNodes.pop();
        int lvl = qLevels.front();   qLevels.pop();

        // Якщо перейшли на новий рівень, друкуємо його заголовок
        if (lvl > currentLevel) {
            if (currentLevel != -1) std::cout << "\n";
            currentLevel = lvl;
            std::cout << "Niv. " << currentLevel << ": ";
        }

        // 1. Формуємо один "логічний" вузол 2-3-4 дерева
        std::cout << "(";
        if (isRED(curr->left)) {
            std::cout << curr->left->key << ",";
        }
        
        std::cout << curr->key;
        
        if (isRED(curr->right)) {
            std::cout << "," << curr->right->key;
        }
        std::cout << ") ";

        // 2. Додаємо в чергу наступних чорних дітей
        // Перевіряємо ліву гілку
        if (isRED(curr->left)) {
            if (curr->left->left)  { qNodes.push(curr->left->left);  qLevels.push(lvl + 1); }
            if (curr->left->right) { qNodes.push(curr->left->right); qLevels.push(lvl + 1); }
        } else {
            if (curr->left) { qNodes.push(curr->left); qLevels.push(lvl + 1); }
        }

        // Перевіряємо праву гілку
        if (isRED(curr->right)) {
            if (curr->right->left)  { qNodes.push(curr->right->left);  qLevels.push(lvl + 1); }
            if (curr->right->right) { qNodes.push(curr->right->right); qLevels.push(lvl + 1); }
        } else {
            if (curr->right) { qNodes.push(curr->right); qLevels.push(lvl + 1); }
        }
    }
    std::cout << "\n"; // Завершуємо вивід
}