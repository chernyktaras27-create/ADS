#include "CMyVektor.h"
#include <cmath>
#include <iostream>
#include <stdexcept>
using namespace std;

//Konstructor
CMyVektor::CMyVektor(int n) : data(n) {}

// 
int CMyVektor::size() const {
    return data.size();
}

// set
void CMyVektor::set(int i, double value) {
    data[i] = value;
}

// get
double CMyVektor::get(int i) const {
    return data[i];
}

// operator[]
double& CMyVektor::operator[](int i) {
    return data[i];
}

double CMyVektor::operator[](int i) const {
    return data[i];
}
double mySqrt(double x) {
    if (x == 0) return 0;

    double y = x;

    for (int i = 0; i < 20; i++) {
        y = 0.5 * (y + x / y);
    }

    return y;
}


double CMyVektor::length() const {
    double sum = 0.0;

    for (int i = 0; i < data.size(); i++) {
        sum += data[i] * data[i];
    }

    return sqrt(sum);
}

CMyVektor operator+(const CMyVektor& a, const CMyVektor& b) {

    if (a.size() != b.size()) {
        //CMyVektor result(0);
        //return result;
        throw std::invalid_argument("Vector sizes are not equal");
    }

    int n = a.size();
    CMyVektor result(n);

    for (int i = 0; i < n; i++) {
        result[i] = a[i] + b[i];
    }

    return result;
}
CMyVektor operator*(double lambda, const CMyVektor& a) {

    int n = a.size();
    CMyVektor result(n);

    for (int i = 0; i < n; i++) {
        result[i] = lambda * a[i];
    }

    return result;
}