#include <iostream>
#include "CMyVektor.h"
#include "C_DGLSolver.h"
using namespace std;

CMyVektor dgl_system(CMyVektor y, double x) {
    CMyVektor res(2); // Вектор похідних з 2 елементів
    res.set(0, 2.0 * y.get(1) - x * y.get(0));
    res.set(1, y.get(0) * y.get(1) - 2.0 * x * x * x);
    return res;
}
double dgl_dritte_ordnung(CMyVektor y, double x) {
    return 2.0 * x * y.get(1) * y.get(2) + 2.0 * y.get(0) * y.get(0) * y.get(1);
}
int main() {
    C_DGLSolver solver_system(dgl_system); // Передаємо нашу систему
   
    CMyVektor y_start_sys(2); // Початкові умови: y1(0)=0, y2(0)=1
    y_start_sys.set(0, 0.0);
    y_start_sys.set(1, 1.0);

    // Викликаємо Euler на 100 кроків від 0 до 2, printSteps = true
    solver_system.euler(0.0, 2.0, 100, y_start_sys, true);

    cout << "dausche dlya heun\n\n"; // Розділювач як у твоєму прикладі

    // Викликаємо Heun на 100 кроків від 0 до 2, printSteps = true
    solver_system.heun(0.0, 2.0, 100, y_start_sys, true);

    
    C_DGLSolver solver_dritte(dgl_dritte_ordnung); 
    
    CMyVektor y_start_dritte(3); // Початкові умови: y(1)=1, y'(1)=-1, y''(1)=2
    y_start_dritte.set(0, 1.0);
    y_start_dritte.set(1, -1.0);
    y_start_dritte.set(2, 2.0);

    int schritte_array[] = {10, 100, 1000, 10000};
    
    for (int s : schritte_array) {
        // Рахуємо Euler від 1 до 2. printSteps = false
        CMyVektor res_euler = solver_dritte.euler(1.0, 2.0, s, y_start_dritte, false);
        
        // Похибка = Наближене значення - Точне значення (0.5)
        // Беремо лише нульовий елемент res_euler.get(0), бо нас цікавить саме функція y, а не її похідні
        double abweichung_euler = res_euler.get(0) - 0.5;
        cout << "Abweichung bei Euler bei " << s << " Schritten: " << abweichung_euler << "\n";

        // Рахуємо Heun від 1 до 2. printSteps = false
        CMyVektor res_heun = solver_dritte.heun(1.0, 2.0, s, y_start_dritte, false);
        double abweichung_heun = res_heun.get(0) - 0.5;
        cout << "Abweichung bei Heun  bei " << s << " Schritten: " << abweichung_heun << "\n";
    }


    system("pause");
    return 0;
}