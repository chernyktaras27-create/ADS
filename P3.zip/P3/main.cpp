#define CATCH_CONFIG_RUNNER
#include <iostream>
#include "RedBlackBST.h"
#include "catch.h"

using namespace std;

void mainscreenMenu()
{
    std::cout << "----------------------------------------" << endl
         << "1) Datensatz einfuegen, manuell " << endl
         << "2) Datenstruktur anzeigen " << endl
         << "3) Programm beenden " << endl
         << "?>";
}

void mainscreenAddNode(RedBlackBST &ref)
{
    int    key;

    std::cout << "+ Bitte geben Sie die den Schluessel ein:" << endl;
    std::cout << " Key ?> ";
    std::cin >> key;
    bool res = ref.insert(key);
    if (res) {
        std::cout << "+ Ihr Datensatz wurde eingefuegt" << endl;
    }
}


void mainscreenPrintTree(RedBlackBST &ref)
{
    ref.print();
}

int main()
{
    Catch::Session().run();
    int numbers[] = {503, 502, 403, 1002, 2002, 3002};
    int N = sizeof(numbers) / sizeof(int);

    RedBlackBST tree;
    
    for (int i = 0; i < N; i++)
        tree.insert(numbers[i]);
    
    tree.print();
    //*****************************************

    int menuOption = 0;
    while (true)
    {
        do
        {
            mainscreenMenu();
            cin >> menuOption;
        } while (menuOption < 1 || menuOption > 5);

        switch (menuOption)
        {
        case 1:
            mainscreenAddNode(tree);
            break;
        case 2:
            mainscreenPrintTree(tree);
            break;
        case 3:
            return 0;
        }
    
    }
    mainscreenMenu();

    //
    ///////////////////////////////////////
    system("PAUSE");

    return 0;
}