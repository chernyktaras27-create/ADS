#define TEST_FILE test_RedBlackBST

#include "catch.h"
#include <vector>
#include "RedBlackBST.h"
#include "iostream"
#include <string>
bool noRedRed(Node* node) {
    if (node == nullptr) return true;

    if (node->color == true) {
        if (node->left && node->left->color == true) return false;
        if (node->right && node->right->color == true) return false;
    }

    return noRedRed(node->left) && noRedRed(node->right);
}

bool blackHeight(Node* node, int& height) {
    if (node == nullptr) {
        height = 1;
        return true;
    }

    int leftHeight = 0;
    int rightHeight = 0;

    if (!blackHeight(node->left, leftHeight)) return false;
    if (!blackHeight(node->right, rightHeight)) return false;

	if (leftHeight != rightHeight) return false;

    height = leftHeight + (node->color == false ? 1 : 0);
    return true;
}

TEST_CASE("Einfache Links Rotation"){
	RedBlackBST tree;
	SECTION("Baum aufsetzen (Einfache Links Rotation Test), 3 Knoten"){
		int numbers[8] = {20, 10, 30};

		for(int i = 0; i < 3; i++){
			tree.insert(numbers[i]);
		}

		if(REQUIRE_BOOL(tree.getRoot() != nullptr)){
			REQUIRE(tree.getRoot()->val == 20);
			REQUIRE(tree.getRoot()->color == false);

			REQUIRE(tree.getRoot()->left->val == 10);
			REQUIRE(tree.getRoot()->left->color == true);

			REQUIRE(tree.getRoot()->right->val == 30);
			REQUIRE(tree.getRoot()->right->color == true);
		}

	}


	SECTION("Extra groesseren Knoten hinzufuegen"){		
		tree.insert(34);

		if(REQUIRE_BOOL(tree.getRoot() != nullptr)){
			REQUIRE(tree.getRoot()->val == 20);
			REQUIRE(tree.getRoot()->color == false);

			REQUIRE(tree.getRoot()->left->val == 10);
			REQUIRE(tree.getRoot()->left->color == false);

			REQUIRE(tree.getRoot()->right->val == 30);
			REQUIRE(tree.getRoot()->right->color == false);

			REQUIRE(tree.getRoot()->right->right->val == 34);
			REQUIRE(tree.getRoot()->right->right->color == true);
		}
	}

	SECTION("Erste Links Rotation"){
		tree.insert(38);
		if(REQUIRE_BOOL(tree.getRoot() != nullptr)){
			REQUIRE(tree.getRoot()->val == 20);
			REQUIRE(tree.getRoot()->color == false);

			REQUIRE(tree.getRoot()->left->val == 10);
			REQUIRE(tree.getRoot()->left->color == false);

			REQUIRE(tree.getRoot()->right->val == 34);
			REQUIRE(tree.getRoot()->right->color == false);

			REQUIRE(tree.getRoot()->right->left->val == 30);
			REQUIRE(tree.getRoot()->right->left->color == true);

			REQUIRE(tree.getRoot()->right->right->val == 38);
			REQUIRE(tree.getRoot()->right->right->color == true);
		}
	}

	SECTION("Zweite Links Rotation"){
		tree.insert(40);
		
		if(REQUIRE_BOOL(tree.getRoot() != nullptr)){
			REQUIRE(tree.getRoot()->val == 20);
			REQUIRE(tree.getRoot()->color == false);

			REQUIRE(tree.getRoot()->left->val == 10);
			REQUIRE(tree.getRoot()->left->color == false);

			REQUIRE(tree.getRoot()->right->val == 34);
			REQUIRE(tree.getRoot()->right->color == true);

			REQUIRE(tree.getRoot()->right->left->val == 30);
			REQUIRE(tree.getRoot()->right->left->color == false);

			REQUIRE(tree.getRoot()->right->right->val == 38);
			REQUIRE(tree.getRoot()->right->right->color == false);
			
			REQUIRE(tree.getRoot()->right->right->right->val == 40);
			REQUIRE(tree.getRoot()->right->right->right->color == true);
		}
	}
}

TEST_CASE("Einfache Rechts Rotation"){
	RedBlackBST tree;
	SECTION("Baum aufsetzen (Einfache Rechts Rotation Test), 3 Knoten"){
		int numbers[8] = { 20, 10, 30};

		for(int i = 0; i < 3; i++){
			tree.insert(numbers[i]);
		}

		if(REQUIRE_BOOL(tree.getRoot() != nullptr)){
			REQUIRE(tree.getRoot()->val == 20);
			REQUIRE(tree.getRoot()->color == false);

			REQUIRE(tree.getRoot()->left->val == 10);
			REQUIRE(tree.getRoot()->left->color == true);

			REQUIRE(tree.getRoot()->right->val == 30);
			REQUIRE(tree.getRoot()->right->color == true);
		}
	}
	
	SECTION("Kleineren Knoten hinzufuegen"){		
		tree.insert(8);

		if(REQUIRE_BOOL(tree.getRoot() != nullptr)){
			REQUIRE(tree.getRoot()->val == 20);
			REQUIRE(tree.getRoot()->color == false);

			REQUIRE(tree.getRoot()->left->val == 10);
			REQUIRE(tree.getRoot()->left->color == false);

			REQUIRE(tree.getRoot()->right->val == 30);
			REQUIRE(tree.getRoot()->right->color == false);

			REQUIRE(tree.getRoot()->left->left->val == 8);
			REQUIRE(tree.getRoot()->left->left->color == true);
		}
	}
	
	SECTION("Erste Rechts Rotation"){
		tree.insert(5);

		if(REQUIRE_BOOL(tree.getRoot() != nullptr)){
			REQUIRE(tree.getRoot()->val == 20);
			REQUIRE(tree.getRoot()->color == false);

			REQUIRE(tree.getRoot()->left->val == 8);
			REQUIRE(tree.getRoot()->left->color == false);

			REQUIRE(tree.getRoot()->right->val == 30);
			REQUIRE(tree.getRoot()->right->color == false);

			REQUIRE(tree.getRoot()->left->left->val == 5);
			REQUIRE(tree.getRoot()->left->left->color == true);

			REQUIRE(tree.getRoot()->left->right->val == 10);
			REQUIRE(tree.getRoot()->left->right->color == true);
		}
	}

	SECTION("Zweite Links Rotation"){
		tree.insert(2);
		if(REQUIRE_BOOL(tree.getRoot() != nullptr)){
			REQUIRE(tree.getRoot()->val == 20);
			REQUIRE(tree.getRoot()->color == false);

			REQUIRE(tree.getRoot()->left->val == 8);
			REQUIRE(tree.getRoot()->left->color == true);

			REQUIRE(tree.getRoot()->right->val == 30);
			REQUIRE(tree.getRoot()->right->color == false);

			REQUIRE(tree.getRoot()->left->left->val == 5);
			REQUIRE(tree.getRoot()->left->left->color == false);

			REQUIRE(tree.getRoot()->left->right->val == 10);
			REQUIRE(tree.getRoot()->left->right->color == false);
			
			REQUIRE(tree.getRoot()->left->left->left->val == 2);
			REQUIRE(tree.getRoot()->left->left->left->color == true);
		}
	}
}

TEST_CASE("Doppelte Rotation Links-Rechts"){
	RedBlackBST tree;
	SECTION("Baum aufsetzen (LR Rotation), 4 Knoten"){
		int numbers[8] = { 20, 10, 30, 34};

		for(int i = 0; i < 4; i++){
			tree.insert(numbers[i]);
		}

		if(REQUIRE_BOOL(tree.getRoot() != nullptr)){
			REQUIRE(tree.getRoot()->val == 20);
			REQUIRE(tree.getRoot()->color == false);

			REQUIRE(tree.getRoot()->left->val == 10);
			REQUIRE(tree.getRoot()->left->color == false);

			REQUIRE(tree.getRoot()->right->val == 30);
			REQUIRE(tree.getRoot()->right->color == false);

			REQUIRE(tree.getRoot()->right->right->val == 34);
			REQUIRE(tree.getRoot()->right->right->color == true);
		}
	}

	SECTION("Links-Rechts Rotation"){
		tree.insert(32);

		if(REQUIRE_BOOL(tree.getRoot() != nullptr)){
			REQUIRE(tree.getRoot()->val == 20);
			REQUIRE(tree.getRoot()->color == false);

			REQUIRE(tree.getRoot()->left->val == 10);
			REQUIRE(tree.getRoot()->left->color == false);

			REQUIRE(tree.getRoot()->right->val == 32);
			REQUIRE(tree.getRoot()->right->color == false);

			REQUIRE(tree.getRoot()->right->right->val == 34);
			REQUIRE(tree.getRoot()->right->right->color == true);
			
			REQUIRE(tree.getRoot()->right->left->val == 30);
			REQUIRE(tree.getRoot()->right->left->color == true);
		}
	}
}

TEST_CASE("Doppelte Rotation Rechts-Links"){
	RedBlackBST tree;
	SECTION("Baum aufsetzen (RL Rotation), 4 Knoten"){
		int numbers[8] = { 20, 10, 30, 5};

		for(int i = 0; i < 4; i++){
			tree.insert(numbers[i]);
		}
		if(REQUIRE_BOOL(tree.getRoot() != nullptr)){
			REQUIRE(tree.getRoot()->val == 20);
			REQUIRE(tree.getRoot()->color == false);

			REQUIRE(tree.getRoot()->left->val == 10);
			REQUIRE(tree.getRoot()->left->color == false);

			REQUIRE(tree.getRoot()->right->val == 30);
			REQUIRE(tree.getRoot()->right->color == false);

			REQUIRE(tree.getRoot()->left->left->val == 5);
			REQUIRE(tree.getRoot()->left->left->color == true);
		}
	}

	SECTION("Links-Rechts Rotation"){
		tree.insert(8);

		if(REQUIRE_BOOL(tree.getRoot() != nullptr)){
			REQUIRE(tree.getRoot()->val == 20);
			REQUIRE(tree.getRoot()->color == false);

			REQUIRE(tree.getRoot()->left->right->val == 10);
			REQUIRE(tree.getRoot()->left->right->color == true);

			REQUIRE(tree.getRoot()->right->val == 30);
			REQUIRE(tree.getRoot()->right->color == false);

			REQUIRE(tree.getRoot()->left->val == 8);
			REQUIRE(tree.getRoot()->right->color == false);
			
			REQUIRE(tree.getRoot()->left->left->val == 5);
			REQUIRE(tree.getRoot()->left->left->color == true);
		}
	}
}

TEST_CASE("Pruefung der Methoden RedBlackBST::insert() - Simple") {

	int numbers[8] = { 30,20,40,10,25,50,22,28 };
	RedBlackBST tree;
	for (int i = 0; i < 8; i++) {
		tree.insert(numbers[i]);
	}
	if(REQUIRE_BOOL(tree.getRoot() != nullptr)){
		REQUIRE(tree.getRoot()->val == 30);
		REQUIRE(tree.getRoot()->left->val == 20);
		REQUIRE(tree.getRoot()->left->left->val == 10);
		REQUIRE(tree.getRoot()->left->right->val == 25);
		REQUIRE(tree.getRoot()->left->right->left->val == 22);
		REQUIRE(tree.getRoot()->left->right->right->val == 28);
		REQUIRE(tree.getRoot()->right->val == 40);
		REQUIRE(tree.getRoot()->right->right->val == 50);
	}
}

TEST_CASE("Pruefung der Methoden RedBlackBST::insert() - Doppelrotation") {
	int numbers[9] = { 30,20,40,10,25,50,22,28,26};
	RedBlackBST tree;
	for (int i = 0; i < 9; i++) {
		tree.insert(numbers[i]);
	}
	if(REQUIRE_BOOL(tree.getRoot() != nullptr)){
		REQUIRE(tree.getRoot()->val == 25);
		REQUIRE(tree.getRoot()->left->val == 20);
		REQUIRE(tree.getRoot()->left->left->val == 10);
		REQUIRE(tree.getRoot()->left->right->val == 22);
		REQUIRE(tree.getRoot()->right->val == 30);
		REQUIRE(tree.getRoot()->right->left->val == 28);
		REQUIRE(tree.getRoot()->right->left->left->val == 26);
		REQUIRE(tree.getRoot()->right->right->val == 40);
		REQUIRE(tree.getRoot()->right->right->right->val == 50);
	}
}

TEST_CASE("Pruefung der Methoden RedBlackBST::insert() - Doppelrotation2") {
	int numbers[9] = {20,10,30,25,40,22,28,50,26};
	RedBlackBST tree;
	for (int i = 0; i < 9; i++) {
		tree.insert(numbers[i]);
	}
	if(REQUIRE_BOOL(tree.getRoot() != nullptr)){
		REQUIRE(tree.getRoot()->val == 25);
		REQUIRE(tree.getRoot()->left->val == 20);
		REQUIRE(tree.getRoot()->left->left->val == 10);
		REQUIRE(tree.getRoot()->left->right->val == 22);
		REQUIRE(tree.getRoot()->right->val == 30);
		REQUIRE(tree.getRoot()->right->left->val == 28);
		REQUIRE(tree.getRoot()->right->left->left->val == 26);
		REQUIRE(tree.getRoot()->right->right->val == 40);
		REQUIRE(tree.getRoot()->right->right->right->val == 50);
	}
}

TEST_CASE("Pruefung der Rot-Schwarz-Baum Eigenschaften - Grosser Baum Vollstaendig Korrekt") {
    RedBlackBST tree;

    int numbers[14] = { 30,20,40,10,25,50,22,28,26,5,2,12,55,60 };
    for (int i = 0; i < 14; i++) {
        tree.insert(numbers[i]);
    }

	SECTION("Wurzel ist schwarz"){
		// 1. Wurzel ist schwarz
		if(REQUIRE_BOOL(tree.getRoot() != nullptr))
			REQUIRE(tree.getRoot()->color == false);
	}

	SECTION("Keine zwei roten Knoten hintereinander"){
		// 2. Keine zwei roten Knoten hintereinander
		if(REQUIRE_BOOL(tree.getRoot() != nullptr))	
			REQUIRE(noRedRed(tree.getRoot()));	
	}


	// 3. Schwarz-Höhe prüfen: alle root-to-leaf Pfade
    int blackCount[15] = {0};
    int idx = 0;

	SECTION("Schwarz-Hoehe pruefen"){
		
		if(REQUIRE_BOOL(tree.getRoot() != nullptr)){
			// Pfad 1: root -> left -> left -> left -> left (25->20->5->2->NIL Links)
			if (tree.getRoot()->color == false) blackCount[idx]++;
			if (tree.getRoot()->left && tree.getRoot()->left->color == false) blackCount[idx]++;
			if (tree.getRoot()->left->left && tree.getRoot()->left->left->color == false) blackCount[idx]++;
			if (tree.getRoot()->left->left->left && tree.getRoot()->left->left->left->color == false) blackCount[idx]++;
			if (tree.getRoot()->left->left->left->left && tree.getRoot()->left->left->left->left->color == false) blackCount[idx]++;
			idx++;

			// Pfad 2: root -> left -> left -> left -> left (25->20->5->2->NIL Rechts)
			if (tree.getRoot()->color == false) blackCount[idx]++;
			if (tree.getRoot()->left && tree.getRoot()->left->color == false) blackCount[idx]++;
			if (tree.getRoot()->left->left && tree.getRoot()->left->left->color == false) blackCount[idx]++;
			if (tree.getRoot()->left->left->left && tree.getRoot()->left->left->left->color == false) blackCount[idx]++;
			if (tree.getRoot()->left->left->left->right && tree.getRoot()->left->left->left->right->color == false) blackCount[idx]++;
			idx++;

			// Pfad 3: root -> left -> left -> right -> left (25->20->5->10->NIL Links)
			if (tree.getRoot()->color == false) blackCount[idx]++;
			if (tree.getRoot()->left && tree.getRoot()->left->color == false) blackCount[idx]++;
			if (tree.getRoot()->left->left && tree.getRoot()->left->left->color == false) blackCount[idx]++;
			if (tree.getRoot()->left->left->right && tree.getRoot()->left->left->right->color == false) blackCount[idx]++;
			if (tree.getRoot()->left->left->right->left && tree.getRoot()->left->left->right->left->color == false) blackCount[idx]++;
			idx++;

			// Pfad 4: root -> left -> left -> right -> right-> left (25->20->5->10->12->NIL Links)
			if (tree.getRoot()->color == false) blackCount[idx]++;
			if (tree.getRoot()->left && tree.getRoot()->left->color == false) blackCount[idx]++;
			if (tree.getRoot()->left->left && tree.getRoot()->left->left->color == false) blackCount[idx]++;
			if (tree.getRoot()->left->left->right && tree.getRoot()->left->left->right->color == false) blackCount[idx]++;
			if (tree.getRoot()->left->left->right->right && tree.getRoot()->left->left->right->right->color == false) blackCount[idx]++;
			if (tree.getRoot()->left->left->right->right->left && tree.getRoot()->left->left->right->right->left->color == false) blackCount[idx]++;
			idx++;

			// Pfad 5: root -> left -> left -> right -> right-> left (25->20->5->10->12->NIL Rechts)
			if (tree.getRoot()->color == false) blackCount[idx]++;
			if (tree.getRoot()->left && tree.getRoot()->left->color == false) blackCount[idx]++;
			if (tree.getRoot()->left->left && tree.getRoot()->left->left->color == false) blackCount[idx]++;
			if (tree.getRoot()->left->left->right && tree.getRoot()->left->left->right->color == false) blackCount[idx]++;
			if (tree.getRoot()->left->left->right->right && tree.getRoot()->left->left->right->right->color == false) blackCount[idx]++;
			if (tree.getRoot()->left->left->right->right->right && tree.getRoot()->left->left->right->right->right->color == false) blackCount[idx]++;
			idx++;

			// Pfad 6: root -> left -> left -> left -> right (25->20->22->NIL Links)
			if (tree.getRoot()->color == false) blackCount[idx]++;
			if (tree.getRoot()->left && tree.getRoot()->left->color == false) blackCount[idx]++;
			if (tree.getRoot()->left->right && tree.getRoot()->left->right->color == false) blackCount[idx]++;
			if (tree.getRoot()->left->right->left && tree.getRoot()->left->right->left->color == false) blackCount[idx]++;
			idx++;

			// Pfad 7: root -> left -> left -> left -> right (25->20->22->NIL Rechts)
			if (tree.getRoot()->color == false) blackCount[idx]++;
			if (tree.getRoot()->left && tree.getRoot()->left->color == false) blackCount[idx]++;
			if (tree.getRoot()->left->right && tree.getRoot()->left->right->color == false) blackCount[idx]++;
			if (tree.getRoot()->left->right->right && tree.getRoot()->left->right->right->color == false) blackCount[idx]++;
			idx++;

			// Pfad 8: root -> right -> left -> left -> left (25->30->28->26->NIL Links)
			if (tree.getRoot()->color == false) blackCount[idx]++;
			if (tree.getRoot()->right && tree.getRoot()->right->color == false) blackCount[idx]++;
			if (tree.getRoot()->right->left && tree.getRoot()->right->left->color == false) blackCount[idx]++;
			if (tree.getRoot()->right->left->left && tree.getRoot()->right->left->left->color == false) blackCount[idx]++;
			if (tree.getRoot()->right->left->left->left && tree.getRoot()->right->left->left->left->color == false) blackCount[idx]++;
			idx++;

			// Pfad 9: root -> right -> left -> left -> right (25->30->28->26->NIL Rechts)
			if (tree.getRoot()->color == false) blackCount[idx]++;
			if (tree.getRoot()->right && tree.getRoot()->right->color == false) blackCount[idx]++;
			if (tree.getRoot()->right->left && tree.getRoot()->right->left->color == false) blackCount[idx]++;
			if (tree.getRoot()->right->left->left && tree.getRoot()->right->left->left->color == false) blackCount[idx]++;
			if (tree.getRoot()->right->left->left->right && tree.getRoot()->right->left->left->right->color == false) blackCount[idx]++;
			idx++;

			// Pfad 10: root -> right -> left -> right (25->30->28->NIL Rechts)
			if (tree.getRoot()->color == false) blackCount[idx]++;
			if (tree.getRoot()->right && tree.getRoot()->right->color == false) blackCount[idx]++;
			if (tree.getRoot()->right->left && tree.getRoot()->right->left->color == false) blackCount[idx]++;
			if (tree.getRoot()->right->left->right && tree.getRoot()->right->left->right->color == false) blackCount[idx]++;
			idx++;

			// Pfad 11: root -> right -> right -> left -> left (25->30->50->40->NIL Links)
			if (tree.getRoot()->color == false) blackCount[idx]++;
			if (tree.getRoot()->right && tree.getRoot()->right->color == false) blackCount[idx]++;
			if (tree.getRoot()->right->right && tree.getRoot()->right->right->color == false) blackCount[idx]++;
			if (tree.getRoot()->right->right->left && tree.getRoot()->right->right->left->color == false) blackCount[idx]++;
			if (tree.getRoot()->right->right->left->left && tree.getRoot()->right->right->left->left->color == false) blackCount[idx]++;
			idx++;

			// Pfad 12: root -> right -> right -> left -> right (25->30->50->40->NIL Right)
			if (tree.getRoot()->color == false) blackCount[idx]++;
			if (tree.getRoot()->right && tree.getRoot()->right->color == false) blackCount[idx]++;
			if (tree.getRoot()->right->right && tree.getRoot()->right->right->color == false) blackCount[idx]++;
			if (tree.getRoot()->right->right->left && tree.getRoot()->right->right->left->color == false) blackCount[idx]++;
			if (tree.getRoot()->right->right->left->right && tree.getRoot()->right->right->left->right->color == false) blackCount[idx]++;
			idx++;

			// Pfad 13: root -> right -> right -> right -> left (25->30->50->55->NIL Left)
			if (tree.getRoot()->color == false) blackCount[idx]++;
			if (tree.getRoot()->right && tree.getRoot()->right->color == false) blackCount[idx]++;
			if (tree.getRoot()->right->right && tree.getRoot()->right->right->color == false) blackCount[idx]++;
			if (tree.getRoot()->right->right->right && tree.getRoot()->right->right->right->color == false) blackCount[idx]++;
			if (tree.getRoot()->right->right->right->left && tree.getRoot()->right->right->right->left->color == false) blackCount[idx]++;
			idx++;

			// Pfad 14: root -> right -> right -> right -> right -> left (25->30->50->55->60->NIL Left)
			if (tree.getRoot()->color == false) blackCount[idx]++;
			if (tree.getRoot()->right && tree.getRoot()->right->color == false) blackCount[idx]++;
			if (tree.getRoot()->right->right && tree.getRoot()->right->right->color == false) blackCount[idx]++;
			if (tree.getRoot()->right->right->right && tree.getRoot()->right->right->right->color == false) blackCount[idx]++;
			if (tree.getRoot()->right->right->right->right && tree.getRoot()->right->right->right->right->color == false) blackCount[idx]++;
			if (tree.getRoot()->right->right->right->right->left && tree.getRoot()->right->right->right->right->left->color == false) blackCount[idx]++;
			idx++;

			// Pfad 15: root -> right -> right -> right -> right -> right (25->30->50->55->60->NIL Right)
			if (tree.getRoot()->color == false) blackCount[idx]++;
			if (tree.getRoot()->right && tree.getRoot()->right->color == false) blackCount[idx]++;
			if (tree.getRoot()->right->right && tree.getRoot()->right->right->color == false) blackCount[idx]++;
			if (tree.getRoot()->right->right->right && tree.getRoot()->right->right->right->color == false) blackCount[idx]++;
			if (tree.getRoot()->right->right->right->right && tree.getRoot()->right->right->right->right->color == false) blackCount[idx]++;
			if (tree.getRoot()->right->right->right->right->right && tree.getRoot()->right->right->right->right->right->color == false) blackCount[idx]++;
			idx++;
		
			// Prüfe, dass alle Schwarzanzahlen gleich sind
			for (int i = 1; i < 15; i++) {
				REQUIRE(blackCount[i] == blackCount[0]);
			}
		}
	}

	// 3. Schwarz-Höhe prüfen: alle root-to-leaf Pfade
    SECTION("Schwarz-Hoehe pruefen - Rekursiv"){
		int h = 0;
	
		if(REQUIRE_BOOL(tree.getRoot() != nullptr)){
			REQUIRE(blackHeight(tree.getRoot(), h));
		}
	}

}  
	