#pragma once
#include "CMyVektor.h"

class C_DGLSolver
{
private:
CMyVektor (*f_system)(CMyVektor y, double x);
double (*f_n_ordnung)(CMyVektor y, double x);
bool isSystem;
    
public:
    C_DGLSolver(CMyVektor(*f_DGL_System)(CMyVektor y,double x));
    C_DGLSolver(double (*f_DGL_nterOrdnung)(CMyVektor y, double x));
    ~C_DGLSolver();
    CMyVektor ableitungen(CMyVektor y, double x);
    CMyVektor euler(double xStart, double xEnd, int schritte, CMyVektor y_Start,bool printSteps = false);
    CMyVektor heun(double xStart, double xEnd, int schritte, CMyVektor y_Start,bool printSteps = false);

};



