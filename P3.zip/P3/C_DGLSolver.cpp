#include "C_DGLSolver.h"
#include <iostream>

C_DGLSolver::C_DGLSolver(CMyVektor(*f_DGL_System)(CMyVektor y,double x))
{
    f_system =f_DGL_System;
    f_n_ordnung = nullptr;
    isSystem = true;
}
C_DGLSolver::C_DGLSolver(double (*f_DGL_nterOrdnung)(CMyVektor y, double x))
{
    f_n_ordnung =f_DGL_nterOrdnung;
    f_system = nullptr;
    isSystem = false;
}

C_DGLSolver::~C_DGLSolver()
{
}
CMyVektor C_DGLSolver::ableitungen(CMyVektor y, double x){
    if(isSystem){
        return f_system(y, x);
    }else{
     int n = y.size();
     CMyVektor result(n);
     
     for (int i = 0; i < n-1; i++)
     {
        //result[i] = y[n+1];
         result.set(i, y.get(i + 1));
     }
     //result[n-1] =f_n_ordnung(y, x);
     result.set(n - 1, f_n_ordnung(y, x));
     return result;
    }
}

CMyVektor C_DGLSolver::euler(double xStart, double xEnd, int schritte, CMyVektor y_Start, bool printSteps) {
    //Обчислюємо розмір одного кроку h
    double h =(xEnd - xStart)/schritte;

    //Initialisiere die aktuellen Variablen mit Startwerten
    double x_aktuell = xStart;
    CMyVektor y_aktuell = y_Start;

    if (printSteps) {
        std::cout << "h = " << h << "\n\n";
    }

    for (int i = 0; i < schritte; i++)
    {
        // Bestimme den Steigungsvektor am aktuellen Punkt
        CMyVektor y_ableitung = ableitungen(y_aktuell, x_aktuell);

         if (printSteps) {
            std::cout << "Schritt " << i << ":\n";
            std::cout << "\t x = " << x_aktuell << "\n";
            // Використовуємо метод get(), який повертає звичайний double
            std::cout << "\t y = ( " << y_aktuell.get(0) << "; " << y_aktuell.get(1) << ")\n";
            std::cout << "\t y' = ( " << y_ableitung.get(0) << "; " << y_ableitung.get(1) << ")\n\n\n";
        }
        // Робимо крок
        y_aktuell = y_aktuell +(h *y_ableitung);

        // Zeit x vorwärts bewegen
        x_aktuell = x_aktuell + h;
    }
    if (printSteps) {
        std::cout << "Ende bei\n";
        std::cout << "\t x = " << x_aktuell << "\n";
        std::cout << "\t y = ( " << y_aktuell.get(0) << "; " << y_aktuell.get(1) << ")\n\n";
    }
    //Wir geben den Vektor zurück, der am Endpunkt erhalten wurde.
    return y_aktuell;    
}

CMyVektor C_DGLSolver::heun(double xStart, double xEnd, int schritte, CMyVektor y_Start, bool printSteps) {
    double h = (xEnd-xStart)/schritte;
    double x_aktuell = xStart;
    CMyVektor y_aktuell = y_Start;

    if (printSteps) {
        std::cout << "h = " << h << "\n\n";
    }
    for (int i = 0; i < schritte; i++)
    {
        CMyVektor y_ableitung_aktuell = ableitungen(y_aktuell, x_aktuell);
        //Testschritt
        CMyVektor y_test = y_aktuell +(h* y_ableitung_aktuell);
        
        //Bestimmung der Steigung am zukünftigen (Test-)Punkt
        double x_neu = x_aktuell + h;
        CMyVektor y_ableitung_test = ableitungen(y_test,x_neu);
        
        //Berechnung der durchschnittlichen Steigung
        CMyVektor y_ableitung_mittel =0.5 *(y_ableitung_aktuell + y_ableitung_test);
        
        if (printSteps) {
            std::cout << "Schritt " << i << ":\n";
            std::cout << "\t x = " << x_aktuell << "\n";
            std::cout << "\t y = ( " << y_aktuell.get(0) << "; " << y_aktuell.get(1) << ")\n";
            std::cout << "\t y'_orig = ( " << y_ableitung_aktuell.get(0) << "; " << y_ableitung_aktuell.get(1) << ")\n\n";
            std::cout << "\t y_Test = ( " << y_test.get(0) << "; " << y_test.get(1) << ")\n";
            std::cout << "\t y'_Test = ( " << y_ableitung_test.get(0) << "; " << y_ableitung_test.get(1) << ")\n\n";
            std::cout << "\t y'_Mittel = ( " << y_ableitung_mittel.get(0) << "; " << y_ableitung_mittel.get(1) << ")\n\n\n";
        }
        //Wir machen den letzten (wirklichen) Schritt
        y_aktuell = y_aktuell + (h * y_ableitung_mittel);
        //Aktualisiere die aktuelle Zeit x
        x_aktuell = x_neu;
    }
    if (printSteps) {
        std::cout << "Ende bei\n";
        std::cout << "\t x = " << x_aktuell << "\n";
        std::cout << "\t y = ( " << y_aktuell.get(0) << "; " << y_aktuell.get(1) << ")\n\n";
    }
    return y_aktuell;
}