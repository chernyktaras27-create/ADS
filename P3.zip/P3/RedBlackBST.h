#pragma once
#include "Node.h"

class RedBlackBST
{
private:
    Node* mRoot;

    bool  isRED(Node* h);       // s. Sedgewick: S. 464
    Node* rotateLeft(Node* h);  // s. Sedgewick: S. 465
    Node* rotateRight(Node* h); // s. Sedgewick: S. 465
    void  flipColors(Node* h);  // s. Sedgewick: S. 468
    int   size(Node* h);
    bool split4Node(Node* h);

public:
    RedBlackBST();
    Node* getRoot() { return mRoot; }
    bool insert(int key); // iterative insert-Methode
    int  size();
    void print(); // Ausgabe des Baumes als 2-3-4-Baum
    
};
