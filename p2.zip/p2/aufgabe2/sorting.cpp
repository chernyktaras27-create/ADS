// ADS Praktikum 2.1 Sortieren Musterl�sung
// Stand April 2025
#include "sorting.h"
#include <algorithm>



namespace sorting {

	//****************
	// insertionSort *
	//****************   
	void insertionSort(vector<int>& arr)
	{
		for (int i = 1; i < arr.size(); i++)
    {
        int key = arr[i];
        int j = i - 1;

        // рухаємо більші елементи вправо
        while (j >= 0 && arr[j] > key)
        {
            arr[j + 1] = arr[j];
            j--;
        }

        // вставляємо key
        arr[j + 1] = key;
    }
	}


	//************
	// QuickSort *
	//************      
	void quickSort(vector<int>& arr, int left, int right)
	{
	int i = left;
    int j = right;

    // pivot = mittleres Element
    int pivot = arr[(left + right) / 2];

    while (i <= j)
    {
        // Suche nach einem Element >= pivot
        while (arr[i] < pivot)
            i++;

        // Suche nach einem Elementт <= pivot
        while (arr[j] > pivot)
            j--;

        // swap
        if (i <= j)
        {
            swap(arr[i], arr[j]);
            i++;
            j--;
        }
    }

    // Rekursion für die linke Seite
    if (left < j)
        quickSort(arr, left, j);

    // Rekursion für die rechte Seite
    if (i < right)
        quickSort(arr, i, right);
	}


	//************
	// MergeSort *
	//************
	void merge(vector<int>& a, vector<int>& b, int low, int pivot, int high)
{
    int leftIndex = low;          // Startindex der linken Hälfte
    int tempIndex = low;          // Aktuelle Position im Hilfsarray
    int rightIndex = pivot + 1;   // Startindex der rechten Hälfte

    // Solange beide Hälften noch Elemente haben
    while (leftIndex <= pivot && rightIndex <= high)
    {
        // Kleineres Element ins Hilfsarray kopieren
        if (a[leftIndex] <= a[rightIndex])
        {
            b[tempIndex] = a[leftIndex];
            leftIndex++;
        }
        else
        {
            b[tempIndex] = a[rightIndex];
            rightIndex++;
        }

        tempIndex++;
    }

    // Restliche Elemente der linken Hälfte kopieren
    if (leftIndex > pivot)
    {
        for (int k = rightIndex; k <= high; k++)
        {
            b[tempIndex] = a[k];
            tempIndex++;
        }
    }
    else
    {
        // Restliche Elemente der rechten Hälfte kopieren
        for (int k = leftIndex; k <= pivot; k++)
        {
            b[tempIndex] = a[k];
            tempIndex++;
        }
    }

    // Sortierte Werte zurück ins Originalarray kopieren
    for (int k = low; k <= high; k++)
    {
        a[k] = b[k];
    }
}


	void mergeSort(vector<int>& a, vector<int>& b, int low, int high)
	{
		if (low < high)
    {
        int pivot = (low + high) / 2;

        // ліва половина
        mergeSort(a, b, low, pivot);

        // права половина
        mergeSort(a, b, pivot + 1, high);

        // merge
        merge(a, b, low, pivot, high);
    }
	}

	//************
	// Heapsort  *
	//************
	void Heapify(vector<int> &a, int n, int i)
	{
	int largest = i;
    int left = 2 * i + 1;
    int right = 2 * i + 2;

    // якщо left більший
    if (left < n && a[left] > a[largest])
    {
        largest = left;
    }

    // якщо right більший
    if (right < n && a[right] > a[largest])
    {
        largest = right;
    }

    // якщо найбільший не root
    if (largest != i)
    {
        swap(a[i], a[largest]);

        // рекурсивно heapify subtree
        Heapify(a, n, largest);
    }
	}


	void heapSort(vector<int> &a, int n) 
	{
		// build heap
    for (int i = n / 2 - 1; i >= 0; i--)
    {
        Heapify(a, n, i);
    }

    // витягуємо елементи
    for (int i = n - 1; i > 0; i--)
    {
        // root ↔ last
        swap(a[0], a[i]);

        // heapify reduced heap
        Heapify(a, i, 0);
    }
	}

	//************
	// Shellsort *
	//************
	// Hier soll Hibbard implementiert werden
	void shellSort_2n(vector<int> &a, int n)
	{
		// знаходимо найбільший Hibbard gap
    int gap = 1;

    while (gap < n)
    {
        gap = 2 * gap + 1;
    }

    // йдемо назад по gaps
    while (gap > 1)
    {
        gap = gap / 2;

        // insertion sort з gap
        for (int i = gap; i < n; i++)
        {
            int temp = a[i];
            int j = i;

            while (j >= gap && a[j - gap] > temp)
            {
                a[j] = a[j - gap];
                j -= gap;
            }

            a[j] = temp;
        }
    }
	}


	//***************
	// CountingSort *
	//***************
	void countingSort(vector<int>& arr, int left, int right)
	{
		int range = right - left + 1;

    // count array
    vector<int> count(range, 0);

    // zählan  enlemente
    for (int i = 0; i < arr.size(); i++)
    {
        count[arr[i] - left]++;
    }

    // zurückschreiben
    int index = 0;

    for (int i = 0; i < range; i++)
    {
        while (count[i] > 0)
        {
            arr[index] = i + left;

            index++;
            count[i]--;
        }
    }
	}


	//************
	// RadixSort *
	//************
	void countingSortDigit(vector<int>& arr, int exp)
{
    int n = arr.size();

    vector<int> output(n);
    int count[10] = {0};

    // рахуємо цифри
    for (int i = 0; i < n; i++)
    {
        int digit = (arr[i] / exp) % 10;
        count[digit]++;
    }

    // prefix sums
    for (int i = 1; i < 10; i++)
    {
        count[i] += count[i - 1];
    }

    // stable build
    for (int i = n - 1; i >= 0; i--)
    {
        int digit = (arr[i] / exp) % 10;

        output[count[digit] - 1] = arr[i];

        count[digit]--;
    }

    // kopieren zurück
    for (int i = 0; i < n; i++)
    {
        arr[i] = output[i];
    }
}
	void radixSort(vector<int>& arr)
	{
		// suchen max
    int maxVal = arr[0];

    for (int i = 1; i < arr.size(); i++)
{
    if (arr[i] > maxVal)
        maxVal = arr[i];
}

    // exp = 1,10,100,...
    for (int exp = 1; maxVal / exp > 0; exp *= 10)
    {
        countingSortDigit(arr, exp);
    }

	}

	void randomizeVector(vector<int> &array, int n) {
		array.resize(n);

		for (unsigned int i = 0; i < array.size(); i++)
			array[i] = rand() % 10;
			//array[i]=rand() % 1000000;
	}


}





