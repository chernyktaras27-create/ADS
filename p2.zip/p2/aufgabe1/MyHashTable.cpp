#include "MyHashTable.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <math.h>


/**
 * @brief Berechnet den Hash-Wert eines gegebenen Schl�ssels (String) mithilfe der DJB2-Hashfunktion.
 *
 * @param key Der Schl�ssel, der gehasht werden soll.
 * @return Der berechnete Hash-Wert modulo der Tabellengr��e.
 */
unsigned int MyHashTable::hash(const std::string& key) const {
    // DJB2 Variante
    unsigned int h = 5381;
    for (char c : key) {
        h = ((h << 5) + h) + c; // h * 33 + c
    }
    return h % table.size();
}

/**
 * @brief Vergr��ert die Hash-Tabelle und f�hrt ein Rehashing aller existierenden Eintr�ge durch.
 *
 * Diese Methode wird aufgerufen, wenn maxLoadFactor �berschritten wird.
 */
void MyHashTable::rehash() {
    int newSize = getNextPrime(2 * table.size());
    std::vector<Entry> newTable(newSize);

    collisionCount = 0; // Zurücksetzen – Zählen nur nach erneutem Hash

    for (const Entry& entry : table) {
        if (!entry.occupied) continue;

        unsigned int hVal = 5381;
        for (char c : entry.acc.website)
            hVal = ((hVal << 5) + hVal) + c;
        unsigned int h = hVal % newSize;

        int M = newSize;
        int R = getLastPrime(M);
        int i = 0;
        unsigned int idx = h;

        while (newTable[idx].occupied) {
            collisionCount++;
            i++;
            if (mHashMethod == 1)       idx = (h + i) % M;
            else if (mHashMethod == 2)  idx = (h + i * i) % M;
            else                        idx = (h + i * (R - h % R)) % M;
        }

        newTable[idx].acc = entry.acc;
        newTable[idx].occupied = true;
    }

    table = std::move(newTable);
}

/**
 * @brief F�gt einen neuen Account in die Hash-Tabelle ein.
 *
 * Je nach gew�hlter Kollisionsbehandlungsstrategie (linear, quadratisch oder doppeltes Hashing)
 * wird ein freier Platz gesucht. Falls maxLoadFactor �berschritten ist, wird vor dem Einf�gen rehashed.
 *
 * @param acc Der einzuf�gende Account.
 */
void MyHashTable::insert(const Account& acc) {
    if ((double)mNumElements / table.size() > 0.6) {
        rehash();
    }

    unsigned int h = hash(acc.website);
    int M = table.size();
    int R = getLastPrime(M);
    int i = 0;
    unsigned int idx = h;

    while (table[idx].occupied) {
        collisionCount++;
        i++;
        if (mHashMethod == 1)       idx = (h + i) % M;
        else if (mHashMethod == 2)  idx = (h + i * i) % M;
        else                        idx = (h + i * (R - h % R)) % M;
    }

    table[idx].acc = acc;
    table[idx].occupied = true;
    mNumElements++;
}

/**
 * @brief �berpr�ft Login-Daten (Website, Benutzername und Passwort-Hash).
 *
 * Durchsucht die Hash-Tabelle nach einem passenden Eintrag und vergleicht den Passwort-Hash.
 *
 * @param website Die Website des Accounts.
 * @param username Der Benutzername.
 * @param passwordHash Der gehashte Wert des Passworts.
 * @return true, wenn die Login-Daten g�ltig sind, sonst false.
 */
bool MyHashTable::login(const std::string& website, const std::string& username, const std::string& passwordHash) const {
    unsigned int h = hash(website);
    int M = table.size();
    int R = getLastPrime(M);
    int i = 0;
    unsigned int idx = h;

    while (table[idx].occupied) {
        if (table[idx].acc.website == website &&
            table[idx].acc.username == username &&
            table[idx].acc.passwordHash == passwordHash) {
            return true;
        }

        i++;
        if (mHashMethod == 1)       idx = (h + i) % M;
        else if (mHashMethod == 2)  idx = (h + i * i) % M;
        else                        idx = (h + i * (R - h % R)) % M;

        // Повне коло — елемент не знайдено
        if (i >= M) break;
    }

    return false;
}

/**
 * @brief Gibt alle gespeicherten Eintr�ge (Website + Benutzername) auf der Konsole aus.
 */
void MyHashTable::listEntries() const {
     for (const auto& entry : table) {
        if (entry.occupied) {
            std::cout << entry.acc.website
                      << " | "
                      << entry.acc.username
                      << std::endl;
        }
    }
   
}

/**
 * @brief Bestimmt die n�chstgr��ere Primzahl nach einer gegebenen Zahl.
 *
 * @param x Startwert f�r die Suche.
 * @return Die n�chstgr��ere Primzahl.
 */
int MyHashTable::getNextPrime(int x) const
{
    x = x + 1;
    bool found = true;
    while (true)
    {
        found = true;
        for (int i = 2; i <= sqrt(x); i++)
        {
            if (x % i == 0)
            {
                found = false;
                break;
            }
        }
        if (found)
        {
            return x;
        }
        x += 1;
    }
}

/**
 * @brief Bestimmt die n�chstkleinere Primzahl vor einer gegebenen Zahl.
 *
 * @param x Startwert f�r die Suche.
 * @return Die n�chstkleinere Primzahl.
 */
int MyHashTable::getLastPrime(int x)const
{
    x = x - 1;
    bool found = true;
    while (true)
    {
        found = true;
        for (int i = 2; i <= sqrt(x); i++)
        {
            if (x % i == 0)
            {
                found = false;
                break;
            }
        }
        if (found)
        {
            return x;
        }
        x -= 1;
    }
}

