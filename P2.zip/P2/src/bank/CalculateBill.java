package bank;

/**
 * Schnittstelle zur Berechnung des endgültigen Transaktionsbetrags.
 */
public interface CalculateBill {

    /**
     * Berechnet den endgültigen Betrag der Transaktion.
     *
     * @return Berechneter Geldbetrag
     */
    double calculate();
}

