package bank;
import java.util.Objects;
/**
 * Repräsentiert eine Einzahlung oder Auszahlung.
 */
public class Payment extends Transaction {

    /**Zinssatz fur Einzahlung zwieschen 0 und 1 */
    private double incomingInterest;

    /** Zinssatz für Auszahlungen zwischen 0 und 1 */
    private double outgoingInterest;

    /**
     * Erstellt eine neue Zahlung ohne zusätzliche Zinsen.
     *
     * @param date Datum der Zahlung
     * @param amount Geldbetrag der Zahlung
     * @param description Beschreibung der Zahlung
     */
    public Payment(String date, double amount, String description) {
        this(date, amount, description, 0.0, 0.0);
    }

    /**
     * Erstellt eine neue Zahlung mit Zinssätzen.
     *
     * @param date Datum der Zahlung
     * @param amount Geldbetrag der Zahlung
     * @param description Beschreibung der Zahlung
     * @param incomingInterest Zinssatz für Einzahlungen
     * @param outgoingInterest Zinssatz für Auszahlungen
     */
    public Payment(String date, double amount, String description,
                   double incomingInterest, double outgoingInterest) {

        super(date, amount, description);

        setIncomingInterest(incomingInterest);
        setOutgoingInterest(outgoingInterest);
    }

    /**
     * Erstellt eine Kopie einer vorhandenen Zahlung.
     *
     * @param other Zu kopierende Zahlung
     */
    public Payment(Payment other) {
        this(other.getDate(), other.getAmount(), other.getDescription(),
                other.getIncomingInterest(), other.getOutgoingInterest());
    }

    /**
     * Gibt den Zinssatz für Einzahlungen zurück.
     *
     * @return Zinssatz für Einzahlungen
     */
    public double getIncomingInterest() {
        return incomingInterest;
    }

    /**
     * Ändert den Zinssatz für Einzahlungen.
     *
     * @param incomingInterest Neuer Zinssatz
     */
    public void setIncomingInterest(double incomingInterest) {
        if (incomingInterest >= 0.0 && incomingInterest <= 1.0) {
            this.incomingInterest = incomingInterest;
        } else {
            System.out.println("Fehler: incomingInterest muss zwischen 0 und 1 liegen.");
        }
    }

    /**
     * Gibt den Zinssatz für Auszahlungen zurück.
     *
     * @return Zinssatz für Auszahlungen
     */
    public double getOutgoingInterest() {
        return outgoingInterest;
    }

    /**
     * Ändert den Zinssatz für Auszahlungen.
     *
     * @param outgoingInterest Neuer Zinssatz
     */
    public void setOutgoingInterest(double outgoingInterest) {
        if (outgoingInterest >= 0.0 && outgoingInterest <= 1.0) {
            this.outgoingInterest = outgoingInterest;
        } else {
            System.out.println("Fehler: outgoingInterest muss zwischen 0 und 1 liegen.");
        }
    }
    /**
     * Berechnet den endgültigen Betrag unter Berücksichtigung der Zinsen.
     *
     * @return Berechneter Geldbetrag
     */
    @Override
    public double calculate() {
        double amount = getAmount();

        if (amount > 0) {
            return amount * (1 - incomingInterest);
        } else if (amount < 0) {
            return amount * (1 + outgoingInterest);
        } else {
            return 0.0;
        }
    }
    /**
     * Gibt alle Informationen der Zahlung zurück.
     *
     * @return Textuelle Darstellung der Zahlung
     */
    @Override
    public String toString() {
        return super.toString() +
                ", Incoming Interest: " + incomingInterest +
                ", Outgoing Interest: " + outgoingInterest;
    }

    /**
     * Vergleicht diese Zahlung mit einem anderen Objekt.
     *
     * @param obj Das zu vergleichende Objekt
     * @return true, wenn alle Attribute gleich sind
     */
    @Override
    public boolean equals(Object obj) {

        if (!super.equals(obj)) {
            return false;
        }

        Payment other = (Payment) obj;

        return Double.compare(incomingInterest, other.incomingInterest) == 0
                && Double.compare(outgoingInterest, other.outgoingInterest) == 0;
    }

    /**
     * Berechnet den Hashcode der Zahlung.
     *
     * @return Hashcode der Zahlung
     */
    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), incomingInterest, outgoingInterest);
    }

}
