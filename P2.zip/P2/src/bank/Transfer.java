package bank;
import java.util.Objects;

/**
 * Repräsentiert eine Überweisung zwischen zwei Akteuren.
 */
public class Transfer extends Transaction {

    /** Absender der Überweisung. */
    private String sender;

    /** Empfänger der Überweisung. */
    private String recipient;


    /**
     * Erstellt eine Überweisung mit Datum, Betrag und Beschreibung.
     *
     * @param date Datum der Überweisung
     * @param amount Überweisungsbetrag
     * @param description Beschreibung der Überweisung
     */
    public Transfer(String date, double amount, String description) {
        this(date, amount, description, "", "");
    }

    /**
     * Erstellt eine Überweisung mit allen Attributen.
     *
     * @param date Datum der Überweisung
     * @param amount Überweisungsbetrag
     * @param description Beschreibung der Überweisung
     * @param sender Absender der Überweisung
     * @param recipient Empfänger der Überweisung
     */
    public Transfer(String date, double amount, String description,
                    String sender, String recipient) {

        super(date, amount, description);

        if (amount <= 0.0) {
            System.out.println("Fehler: Der Überweisungsbetrag muss positiv sein.");
            super.setAmount(0.0);
        }

        setSender(sender);
        setRecipient(recipient);
    }

    /**
     * Erstellt eine Kopie eines vorhandenen Transfer-Objekts.
     *
     * @param other Zu kopierendes Transfer-Objekt
     */
    public Transfer(Transfer other) {
        this(other.getDate(), other.getAmount(), other.getDescription(),
                other.getSender(), other.getRecipient());
    }

    /**
     * Gibt den Absender der Überweisung zurück.
     *
     * @return Absender der Überweisung
     */
    public String getSender() {
        return sender;
    }

    /**
     * Ändert den Absender der Überweisung.
     *
     * @param sender Neuer Absender
     */
    public void setSender(String sender) {
        this.sender = sender;
    }

    /**
     * Gibt den Empfänger der Überweisung zurück.
     *
     * @return Empfänger der Überweisung
     */
    public String getRecipient() {
        return recipient;
    }

    /**
     * Ändert den Empfänger der Überweisung.
     *
     * @param recipient Neuer Empfänger
     */
    public void setRecipient(String recipient) {
        this.recipient = recipient;
    }
    /**
     * Ändert den Überweisungsbetrag.
     *
     * @param amount Neuer Überweisungsbetrag
     */
    @Override
    public void setAmount(double amount) {
        if (amount > 0.0) {
            super.setAmount(amount);
        } else {
            System.out.println("Fehler: Der Überweisungsbetrag muss positiv sein.");
        }
    }
    /**
     * Gibt den unveränderten Überweisungsbetrag zurück.
     *
     * @return Überweisungsbetrag
     */
    @Override
    public double calculate() {
        return getAmount();
    }
    /**
     * Gibt alle Informationen der Überweisung zurück.
     *
     * @return Textuelle Darstellung der Überweisung
     */
    @Override
    public String toString() {
        return super.toString() +
                ", Sender: " + sender +
                ", Recipient: " + recipient;
    }
    /**
     * Vergleicht diese Überweisung mit einem anderen Objekt.
     *
     * @param obj Das zu vergleichende Objekt
     * @return true, wenn alle Attribute gleich sind
     */
    @Override
    public boolean equals(Object obj) {

        if (!super.equals(obj)) {
            return false;
        }

        Transfer other = (Transfer) obj;

        return Objects.equals(sender, other.sender)
                && Objects.equals(recipient, other.recipient);
    }

    /**
     * Berechnet den Hashcode der Überweisung.
     *
     * @return Hashcode der Überweisung
     */
    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), sender, recipient);
    }
}

