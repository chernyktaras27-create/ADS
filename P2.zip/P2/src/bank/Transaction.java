package bank;
import java.util.Objects;
/**
 * Abstrakte Oberklasse für alle Banktransaktionen.
 * Enthält gemeinsame Attribute und Methoden.
 */
public abstract class Transaction implements CalculateBill{

    /** Datum der Transaktion im Format DD.MM.YYYY. */
    private String date;

    /** Geldbetrag der Transaktion. */
    private double amount;

    /** Beschreibung der Transaktion. */

    private String description;

    /**
     * Erstellt eine neue Transaktion.
     *
     * @param date Datum der Transaktion
     * @param amount Geldbetrag der Transaktion
     * @param description Beschreibung der Transaktion
     */
    public Transaction(String date, double amount, String description) {
        this.date = date;
        this.amount = amount;
        this.description = description;
    }
    /**
     * Gibt das Datum der Transaktion zurück.
     *
     * @return Datum der Transaktion
     */
    public String getDate() {
        return date;
    }

    /**
     * Ändert das Datum der Transaktion.
     *
     * @param date Neues Datum der Transaktion
     */
    public void setDate(String date) {
        this.date = date;
    }

    /**
     * Gibt den Geldbetrag der Transaktion zurück.
     *
     * @return Geldbetrag der Transaktion
     */
    public double getAmount() {
        return amount;
    }

    /**
     * Ändert den Geldbetrag der Transaktion.
     *
     * @param amount Neuer Geldbetrag
     */
    public void setAmount(double amount) {
        this.amount = amount;
    }

    /**
     * Gibt die Beschreibung der Transaktion zurück.
     *
     * @return Beschreibung der Transaktion
     */
    public String getDescription() {
        return description;
    }

    /**
     * Ändert die Beschreibung der Transaktion.
     *
     * @param description Neue Beschreibung
     */
    public void setDescription(String description) {
        this.description = description;
    }
    /**
     * Berechnet den endgültigen Betrag der Transaktion.
     *
     * @return Berechneter Geldbetrag
     */
    @Override
    public abstract double calculate();

    /**
     * Gibt die allgemeinen Informationen der Transaktion zurück.
     *
     * @return Textuelle Darstellung der Transaktion
     */
    @Override
    public String toString() {
        return "Date: " + date +
                ", Amount: " + calculate() +
                ", Description: " + description;
    }
    /**
     * Vergleicht diese Transaktion mit einem anderen Objekt.
     *
     * @param obj Das zu vergleichende Objekt
     * @return true, wenn alle gemeinsamen Attribute gleich sind
     */
    @Override
    public boolean equals(Object obj) {

        if (this == obj) {
            return true;
        }

        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }

        Transaction other = (Transaction) obj;

        return Double.compare(amount, other.amount) == 0
                && Objects.equals(date, other.date)
                && Objects.equals(description, other.description);
    }
    /**
     * Berechnet den Hashcode der Transaktion.
     *
     * @return Hashcode der Transaktion
     */
    @Override
    public int hashCode() {
        return Objects.hash(date, amount, description);
    }
}
