
import bank.Payment;
import bank.Transfer;

/**
 * Testklasse für die Banktransaktionen.
 */
public class Main {

    /**
     * Startet die Tests für Payment und Transfer.
     *
     * @param args Kommandozeilenargumente
     */
    public static void main(String[] args) {

        // Payment mit dem ersten Konstruktor
        Payment payment1 = new Payment("18.10.2026", 100.0, "Einzahlung");
        System.out.println(payment1);

        // Payment mit dem zweiten Konstruktor
        Payment payment2 = new Payment("18.10.2026", -50.0, "Auszahlung", 0.05, 0.02);
        System.out.println(payment2);

        // Copy-Konstruktor von Payment
        Payment payment3 = new Payment(payment2);
        System.out.println(payment3);

        // calculate() testen
        System.out.println("\n calculate() Tests");
        System.out.println("Payment 1: " + payment1.calculate());
        System.out.println("Payment 2: " + payment2.calculate());

        // Originalbetrag prüfen
        System.out.println("Originalbetrag Payment 2: " + payment2.getAmount());

        // equals() testen
        System.out.println("\n equals() Tests ");
        System.out.println("Payment-Kopie: " + payment2.equals(payment3));

        // Transfer mit dem ersten Konstruktor
        Transfer transfer1 = new Transfer("18.10.2026", 200.0, "Miete");
        System.out.println(transfer1);

        // Transfer mit dem zweiten Konstruktor
        Transfer transfer2 = new Transfer("18.10.2026", 350.0, "Geld senden", "Taras", "Nazar");
        System.out.println(transfer2);

        // Copy-Konstruktor von Transfer
        Transfer transfer3 = new Transfer(transfer2);
        System.out.println(transfer3);

        // calculate() testen
        System.out.println("Transfer: " + transfer1.calculate());

        // equals() testen
        System.out.println("Transfer-Kopie: " + transfer2.equals(transfer3));

        // Getter und Setter testen
        System.out.println("\n Getter und Setter Tests ");
        payment1.setDescription("Neue Einzahlung");
        System.out.println("Neue Beschreibung: " + payment1.getDescription());

        // Ungültige Zinssätze testen
        System.out.println("\n Ungültige Zinsen ");
        payment1.setIncomingInterest(1.5);
        payment1.setOutgoingInterest(-0.1);

        // Ungültigen Überweisungsbetrag testen
        System.out.println("\n Ungültiger Betrag ");
        transfer2.setAmount(-100.0);
        transfer2.setAmount(0.0);

        // Prüfen, ob der alte Betrag erhalten bleibt
        System.out.println("Betrag nach Fehlern: " + transfer2.getAmount());

        // hashCode() testen
        System.out.println("\n hashCode() Tests ");
        System.out.println(payment2.hashCode() == payment3.hashCode());
        System.out.println(transfer2.hashCode() == transfer3.hashCode());
        // Unterschiedliche Zinssätze vergleichen
        Payment payment4 = new Payment("18.10.2026", -50.0,
                "Auszahlung", 0.10, 0.02);

        System.out.println("Unterschiedliche Payment-Objekte: "
                + payment2.equals(payment4));

        // Unterschiedliche Empfänger vergleichen
        Transfer transfer4 = new Transfer("18.10.2026", 350.0,
                "Geld senden", "Taras", "Andrej");

        System.out.println("Unterschiedliche Transfer-Objekte: "
                + transfer2.equals(transfer4));
    }
}
