package bank;
/* Representiert eine Einzahlung oder Auszahlung*/
public class Payment {
    /* Datum der Zahlung im format DD.MM.YYYY. */
    private String date;

    /* Geldbetrag der Zahlung*/
    private  double amount;

    /*Beschreibung der Zahlung. */
    private String description;

    /*Zinssatz fur Einzahlung zwieschen 0 und 1 */
    private double incomingInterest;

    /* Zinssatz für Auszahlungen zwischen 0 und 1 */
    private double outgoingInterest;

    /* Erstellt eine Zahlung mit datum, Betrag und Beschreibung */
    public Payment(String date, double amount, String description){
        this(date, amount, description,0.0, 0.0);
    }

    /* Erstellt eine Zahlung mit allen Attributen*/
    public Payment(String date, double amount, String description, double incomingInterest, double outgoingInterest) {

        setDate(date);
        setAmount(amount);
        setDescription(description);
        setIncomingInterest(incomingInterest);
        setOutgoingInterest(outgoingInterest);
    }

    /*Erstellt eine Kopie eines vorhandenen Payment-Objekts*/
    public Payment(Payment other) {
        this(other.getDate(), other.getAmount(), other.getDescription(),
                other.getIncomingInterest(), other.getOutgoingInterest());
    }

    /* Gibt das Datum zurück. */
    public String getDate() {
        return date;
    }

    /* Setzt das Datum. */
    public void setDate(String date) {
        this.date = date;
    }


    /* Gibt den Geldbetrag zurück. */
    public double getAmount() {
        return amount;
    }

    /* Setzt den Geldbetrag. */
    public void setAmount(double amount) {
        this.amount = amount;
    }

    /* Gibt die Beschreibung zurück. */
    public String getDescription() {
        return description;
    }

    /* Setzt die Beschreibung. */
    public void setDescription(String description) {
        this.description = description;
    }

    /* Gibt den Zinssatz für Einzahlungen zurück. */
    public double getIncomingInterest() {
        return incomingInterest;
    }

    /* Setzt den Zinssatz für Einzahlungen. */
    public void setIncomingInterest(double incomingInterest) {
        if (incomingInterest >= 0.0 && incomingInterest <= 1.0) {
            this.incomingInterest = incomingInterest;
        } else {
            System.out.println("Fehler: incomingInterest muss zwischen 0 und 1 liegen");
        }
    }


    /* Gibt den Zinssatz für Auszahlungen zurück. */
    public double getOutgoingInterest() {
        return outgoingInterest;
    }

    /* Setzt den Zinssatz für Auszahlungen. */
    public void setOutgoingInterest(double outgoingInterest) {
        if (outgoingInterest >= 0.0 && outgoingInterest <= 1.0) {
            this.outgoingInterest = outgoingInterest;
        } else {
            System.out.println("Fehler: outgoingInterest muss zwischen 0 und 1 liegen.");
        }
    }

    /*Gibt alle Attribute des Objekts auf der Konsole aus*/
    public void printObject() {
        System.out.println("Payment:");
        System.out.println("Date: " + getDate());
        System.out.println("Amount: " + getAmount());
        System.out.println("Description: " + getDescription());
        System.out.println("Incoming interest: " + getIncomingInterest());
        System.out.println("Outgoing interest: " + getOutgoingInterest());
        System.out.println();
    }

}
