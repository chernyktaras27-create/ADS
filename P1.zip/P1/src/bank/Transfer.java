package bank;

/*Repräsentiert eine Überweisung zwischen zwei Akteuren.*/
public class Transfer {

    /* Datum der Überweisung im Format DD.MM.YYYY. */
    private String date;

    /* Überweisungsbetrag. Es sind nur positive Werte erlaubt. */
    private double amount;

    /* Beschreibung der Überweisung. */
    private String description;

    /* Absender der Überweisung. */
    private String sender;

    /* Empfänger der Überweisung. */
    private String recipient;


    /*Erstellt eine Überweisung mit Datum, Betrag und Beschreibung */
    public Transfer(String date, double amount, String description) {
        this(date, amount, description, "", "");
    }

    /*Erstellt eine Überweisung mit allen Attributen*/
    public Transfer(String date, double amount, String description, String sender, String recipient) {

        setDate(date);
        setAmount(amount);
        setDescription(description);
        setSender(sender);
        setRecipient(recipient);
    }

    /* Erstellt eine Kopie eines vorhandenen Transfer-Objekts*/
    public Transfer(Transfer other) {
        this(other.getDate(), other.getAmount(), other.getDescription(), other.getSender(), other.getRecipient());
    }


    /* Gibt das Datum zurück */
    public String getDate() {
        return date;
    }

    /* Setzt das Datum */
    public void setDate(String date) {
        this.date = date;
    }


    /* Gibt den Überweisungsbetrag zurück */
    public double getAmount() {
        return amount;
    }

    /* Setzt den Überweisungsbetrag. Nur positive Werte sind erlaubt */
    public void setAmount(double amount) {
        if (amount > 0.0) {
            this.amount = amount;
        } else {
            System.out.println("Fehler: Der Überweisungsbetrag muss positiv sein.");
        }
    }

    /* Gibt die Beschreibung zurück */
    public String getDescription() {
        return description;
    }

    /*Setzt die Beschreibung */
    public void setDescription(String description) {
        this.description = description;
    }

    /* Gibt den Absender zurück */
    public String getSender() {
        return sender;
    }

    /* Setzt den Absender */
    public void setSender(String sender) {
        this.sender = sender;
    }

    /* Gibt den Empfänger zurück */
    public String getRecipient() {
        return recipient;
    }

    /* Setzt den Empfänger */
    public void setRecipient(String recipient) {
        this.recipient = recipient;
    }

    /*Gibt alle Attribute des Objekts auf der Konsole aus */
    public void printObject() {
        System.out.println("Transfer:");
        System.out.println("Date: " + getDate());
        System.out.println("Amount: " + getAmount());
        System.out.println("Description: " + getDescription());
        System.out.println("Sender: " + getSender());
        System.out.println("Recipient: " + getRecipient());
        System.out.println();
    }
}

