
import bank.Payment;
import bank.Transfer;

/* Startklasse zum Testen der Klassen Payment und Transfer*/
public class Main {
    public static void main(String[] args) {

        // Aufgabe 3: Payment mit dem ersten Konstruktor testen
        Payment payment1 = new Payment("18.10.2026", 100.0, "Einzahlung");
        payment1.printObject();

        // Payment mit dem zweiten Konstruktor testen
        Payment payment2 = new Payment("18.10.2026", -50.0, "Auszahlung", 0.05, 0.02);
        payment2.printObject();

        // Copy-Konstruktor von Payment testen
        Payment payment3 = new Payment(payment2);
        payment3.printObject();

        // Prüfen, ob die Kopie die gleichen Werte besitzt
        System.out.println("Payment-Kopie: " + (payment2.getAmount() == payment3.getAmount()));

        // Transfer mit dem ersten Konstruktor testen
        Transfer transfer1 = new Transfer("18.10.2026", 200.0, "Miete");
        transfer1.printObject();

        // Transfer mit dem zweiten Konstruktor testen
        Transfer transfer2 = new Transfer("18.10.2026", 350.0, "Geld senden", "Taras", "Nazar");
        transfer2.printObject();

        // Copy-Konstruktor von Transfer testen
        Transfer transfer3 = new Transfer(transfer2);
        transfer3.printObject();

        // Prüfen, ob die Kopie die gleichen Werte besitzt
        System.out.println("Transfer-Kopie: " + (transfer2.getAmount() == transfer3.getAmount()));

        // Getter und Setter testen
        payment1.setDescription("Neue Einzahlung");
        System.out.println("Neue Beschreibung: " + payment1.getDescription());

        // Fehlerfall: Ungültiger Zinssatz
        System.out.println("\nTest: Ungültige Zinsen ");
        payment1.setIncomingInterest(1.5);
        payment1.setOutgoingInterest(-0.1);


        // Fehlerfall: Ungültiger Überweisungsbetrag
        System.out.println("\nTest: Ungültiger Betrag");
        transfer2.setAmount(-100.0);
        transfer2.setAmount(0.0);


        // Prüfen, ob der alte Betrag erhalten geblieben ist
        System.out.println(
                "Betrag nach Fehlern: " + transfer2.getAmount()
        );
    }
}

